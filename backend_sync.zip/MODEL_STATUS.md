# MODEL_STATUS.md

Required by §4 of the backend specification:

> If a chosen model fails current Compute validation:
> 1. keep its adapter interface;
> 2. find the closest currently supported Qualcomm model;
> 3. record the replacement in `MODEL_STATUS.md`;
> 4. never fake Snapdragon/NPU support.

This file records what is actually running. It is meant to be edited on the
target machine as exports are validated, not left as written here.

---

## Where this build stands

**No Qualcomm AI Hub model has been compiled, profiled or exported for this
project yet.** The adapters are written and the runtime path to the NPU is
implemented, but nothing has been validated on Snapdragon hardware from this
environment, because this environment has no Snapdragon device attached, and
(re-confirmed directly 2026-09-24, not assumed) this sandbox's own egress
policy blocks the AI Hub API itself — see "Qualcomm AI Hub export/profile
attempt" below for the actual attempt and its authoritative failure reason.

Rather than shipping code that asserts NPU acceleration, every adapter reports
the accelerator the runtime actually gave it, and `GET /api/models/status`
prints the whole picture — including which roles are running deterministic
stand-ins. If a demo claims the NPU, that endpoint should be able to back it.

Run this to see the live state:

```bash
curl http://127.0.0.1:8756/api/models/status
```

---

## Role status

*Updated during the QA-fix pass that replaced synthetic stand-ins with real
local inference wherever this sandbox's environment genuinely allows it (see
"Why some roles are still not real" below for exactly what blocked the
rest, with the evidence gathered rather than an assumption).*

| Role | Intended model (§3) | Adapter | Status in this build | Notes |
|---|---|---|---|---|
| Reasoning VLM | Qwen3-VL-2B-Instruct (current best-supported Snapdragon VLM on Qualcomm AI Hub as of the 2026-09-24 Snapdragon integration phase research — see below) | `GenieXReasoningProvider` (GenieX, Qualcomm's current runtime — new), `QwenVLGenAIProvider` (onnxruntime-genai), `LocalOpenAICompatProvider`, `SmolVLMOnnxProvider` (real CPU dev-mode VLM) | **`heuristic-offline` pinned as the stable default; `onnx-cpu-smolvlm` fully wired up and selectable; `geniex-npu` scaffolded and tried first under `auto` but cannot load in this sandbox — see "Snapdragon integration phase" below** | `GenieXReasoningProvider` is real adapter code against the real `geniex` Python API (ground-truth-inspected from the actual PyPI package source), but `pip install geniex` itself only succeeds on Linux aarch64 / Windows arm64 — confirmed by an actual install attempt in this sandbox, not assumed — so it can only ever report `unavailable` here and the registry correctly falls through. `SmolVLMOnnxProvider` runs the real, Apache-2.0 SmolVLM-500M-Instruct (idefics3) ONNX export through a hand-rolled `onnxruntime` CPU inference loop. `accelerator: cpu`, `npu: false`, `synthetic: false` — never claims Snapdragon/NPU. As of 2026-09-24, evidence gathering is orchestrator-driven (see "Orchestrator-driven evidence gathering" below), which fixed SmolVLM's document/OCR/memory grounding but did not bring it to baseline — see "SmolVLM-500M-Instruct" below for the full post-refactor comparison and why it is not the default yet. `HeuristicReasoningProvider` is pinned in `backend/.env` as the running default. |
| Detection | YOLO11-Detection / YOLO-WORLD | `YoloOnnxDetector`, `YoloWorldDetector` | **Real model running — `yolo-onnx` (Ultralytics YOLO11n, official ONNX export)** | See "Real vision detector — YOLO11n ONNX (2026-09-24)" below. `accelerator: cpu`, `npu: false`, `synthetic: false`; COCO's 80 general classes, not industrial-parts-specific — see that section for what that does and doesn't mean for this app. |
| Classification | EfficientNet-B4 | `EfficientNetOnnxClassifier` | **Not exported** | §7's optional stage. Pre/post-processing complete (ImageNet normalisation, softmax, top-k, crop-to-bbox). Absent, the pipeline skips the stage rather than guessing a class. |
| Segmentation | SAM2 / MobileSAM / YOLO11-Seg | `OnnxSegmenter` | **Not exported** | Session and prototype read-out implemented; mask assembly is finished against the exported head layout. Weight download blocked in this sandbox (see below). |
| Tracking | Track-Anything / EdgeTAM | `EdgeTAMTracker`, `CentroidTracker` | **Classical fallback active — genuinely real** | `CentroidTracker` is a real IoU/centroid associator on CPU, labelled `cpu-classical`, `synthetic: false`. Not a learned tracker and does not claim to be. |
| OCR | EasyOCR / TrOCR | `EasyOCRProvider`, `TrOCROnnxProvider`, **`TesseractOCRProvider` (new)** | **Real model running — `tesseract`** | EasyOCR/TrOCR still need a blocked download; `TesseractOCRProvider` wraps the system `tesseract` binary (apt package, ships its own language data, zero network) via `pytesseract`. Verified end-to-end through `POST /api/photo/analyze` against `nameplate_clear.jpg`: correctly read "SIEMENS / 3-PHASE INDUCTION MOTOR / TYPE 1LE1001-1DB2 / ...". `synthetic: false`, `accelerator: cpu`, `npu: false`. |
| Embeddings | Nomic-Embed-Text / MiniLM-v2 | `NomicOnnxEmbedder` | **Not exported** | Falls back to `LexicalHashEmbedder`, reported as `synthetic: true`. Local RAG works; recall is lexical, not semantic. Weight download blocked in this sandbox (see below). |
| Speech-to-text | Whisper-Base | `WhisperOnnxProvider`, `FasterWhisperProvider`, **`PocketSphinxProvider` (new)** | **Real model running — `pocketsphinx`** | Whisper needs a download from a blocked host (see below). `PocketSphinxProvider` uses the PyPI `pocketsphinx>=5` wheel, which bundles its own default `en-us` acoustic/language model — zero network. Verified end-to-end through `POST /api/voice/transcribe` against real speech (espeak-ng-synthesized, since this sandbox has no microphone/pre-recorded corpus): it genuinely transcribes, at CMUSphinx's well-known lower accuracy than Whisper (a 1990s-architecture acoustic model + generic language model). `synthetic: false`, `accelerator: cpu`, `npu: false`. Kept behind Whisper in the candidate order — this is the reachable fallback, not a claimed equivalent. |
| Text-to-speech | PiperTTS-EN | `PiperTTSProvider`, `EspeakTTSProvider` | **Real neural model running — `piper` (en-us-lessac-medium)** | See "Real Piper voice" below. `EspeakTTSProvider` remains the honest fallback if the voice asset is ever missing. `synthetic: false`, `accelerator: cpu`, `npu: false`. |

### Selecting an alternate

§3 says "Do not hard-wire one model." Every candidate it names is reachable by
configuration, not by editing code:

| Role | Selectable providers |
|---|---|
| reasoning | `geniex-npu`, `onnxruntime-genai`, `local-openai-compat`, `onnx-cpu-smolvlm`, `heuristic-offline` |
| detector | `yolo-onnx`, `yolo-world-onnx` |
| classifier | `efficientnet-onnx` |
| segmenter | `onnx-seg`, `sam2-onnx`, `mobilesam-onnx` |
| tracker | `edgetam-onnx`, `track-anything-onnx`, `cpu-classical` |
| ocr | `easyocr`, `trocr-onnx`, `tesseract` |
| embedding | `nomic-onnx`, `minilm-onnx`, `lexical-hash` |
| stt | `whisper-onnx`, `faster-whisper`, `pocketsphinx` |
| tts | `piper`, `espeak-ng` |

Set `VF_<ROLE>_PROVIDER` to pin one, or leave it `auto` to take the first that
actually loads. `/api/models/status` lists every candidate that was tried and
why each one was skipped.

---

## Why some roles are still not real, in this specific sandbox

This is a fact-finding record, not a guess, so it can be checked and revisited
rather than taken on faith. It is scoped to *this development sandbox* — a
generic cloud Linux container with 2 CPUs, 8 GB RAM, no GPU, and no Snapdragon
silicon — not to what's possible on an actual target device.

**1. Reasoning VLM — Intern3.5-VL-2B specifically.** Validated against the
current Qualcomm AI Hub Models repository/model README
([github.com/qualcomm/ai-hub-models](https://github.com/qualcomm/ai-hub-models),
`src/qai_hub_models/models/intern3_5_vl_2b/`) per §4/§26: it is real, Apache
2.0 plus usage restrictions, and its device-support table does list Snapdragon
X Elite, Snapdragon X Plus 8-Core and Snapdragon X2 Elite as supported
targets, runtime **GenieX/QAIRT**. What blocks it here is not the model's
existence but its export pipeline: `pip install qai-hub-models` +
`qai-hub configure --api_token <token>` requires a **Qualcomm AI Hub account**,
and `qai-hub-models export intern3_5_vl_2b --checkpoint DEFAULT_W4A16` then
needs a **physical or cloud-hosted Snapdragon device slot** to actually
compile/profile against (even with the pre-quantized checkpoint avoiding a
local GPU requirement for that step). Neither an AI Hub account/token nor
Snapdragon hardware/cloud access is self-provisionable from this sandbox.
`LocalOpenAICompatProvider` (already implemented, loopback-only per §24)
would happily talk to a local llama.cpp/Ollama server if one were running
with *any* small GGUF model loaded — the linked development machine has
Ollama **installed but not running** (`http://localhost:11434/api/tags` →
`ERR_CONNECTION_REFUSED`), and this sandbox's own egress proxy rejects every
model registry that could supply one (`huggingface.co`, `cdn-lfs.huggingface.co`,
`aihub.qualcomm.com`, `ollama.com`, `registry.ollama.ai`, `ggml.ggerganov.com`,
confirmed via `curl -sS $HTTPS_PROXY/__agentproxy/status`, an organization
policy decision, not a transient failure). **Given that, and per the user's
explicit direction, the real fallback path is `SmolVLMOnnxProvider`** — see
the dedicated section below for what it is, how it was obtained (downloaded
through the user's own browser on their linked device, transferred in, never
fabricated), and its measured regression impact against the 32-point QA
suite. The heuristic reasoner remains the final, always-honest fallback.

**2. Classifier / segmenter / embedder.** Same root cause: every usable
export (EfficientNet, SAM2/MobileSAM, Nomic-Embed) is distributed via
Hugging Face or a project-specific CDN that this sandbox cannot reach. The
adapters themselves are already real, finished code (pre/post-processing,
ONNX session handling, mask assembly) — see the individual rows above —
waiting only on an asset file. Dropping an exported `.onnx` into
`data/models/<id>/` on a machine with normal network access, or on the actual
target device, needs no code change. (Detection was in this category too
until 2026-09-24 — see below. `github.com`'s release-asset CDN turned out to
be reachable from this sandbox even though `huggingface.co` is not, which is
what unblocked it; that same route does not carry EfficientNet, SAM2/
MobileSAM or Nomic-Embed, which ship only from Hugging Face.)

**3. Whisper specifically — still blocked, re-checked 2026-09-24.** Tried
first, per the fix spec's ordering, before falling back to PocketSphinx.
Re-tested directly rather than assumed, after discovering `github.com`'s
release-asset CDN is reachable (see the detector and Piper sections below):
`ggml.ggerganov.com`, `openaipublic.azureedge.net` and `huggingface.co` are
all explicit policy denials at the egress proxy (`connect_rejected`, gateway
403 to CONNECT — confirmed via `$HTTPS_PROXY/__agentproxy/status`, not a
transient failure), and unlike Ultralytics or Piper, neither `openai/
whisper` nor `ggerganov/whisper.cpp` (now `ggml-org/whisper.cpp`) publish
actual model weights as GitHub release assets — their download tooling
fetches only from the two blocked hosts above. `PocketSphinxProvider`
remains the real, working STT fallback.

**Piper — no longer blocked, real voice installed 2026-09-24.** Checked
directly rather than assumed: `rhasspy/piper-voices` on Hugging Face is
blocked, but Piper's *own* GitHub releases (pre-migration, `v0.0.2`) still
serve real voice model tarballs as release assets, reachable the same way
Ultralytics' YOLO11n export was — see "Real Piper voice" below.

**Bottom line:** nothing here claims NPU or Snapdragon acceleration it
doesn't have — every adapter that loaded reports `cpu`/`npu: false`
truthfully — and nothing fakes a model that isn't running. OCR, STT and TTS
gained a genuinely real, verified, non-synthetic local model in the original
QA-fix pass; Detection and a real neural TTS voice (replacing espeak-ng as
the default) were added in the 2026-09-24 pass — see the dedicated sections
below. The rest remain the same honest heuristic/classical/
unavailable stand-ins as before, now with a documented, checkable reason
rather than an unexplained gap.

---

## SmolVLM-500M-Instruct — real CPU dev-mode VLM (2026-09-24)

**What it is.** `HuggingFaceTB/SmolVLM-500M-Instruct`, Apache-2.0, idefics3
architecture (a llama-family 960-hidden/32-layer text decoder + a 12-layer
vision transformer, `scale_factor: 4` pixel-shuffle). Obtained as the
`_quantized` ONNX export family (`decoder_model_merged_quantized.onnx` 365MB,
`embed_tokens_quantized.onnx` 47MB, `vision_encoder_quantized.onnx` 99MB) —
downloaded through the user's own browser on their linked Windows device
(`huggingface.co` is unreachable from this sandbox directly) and transferred
in via the device-file bridge. `app/models/smolvlm.py` runs all three graphs
through plain `onnxruntime` on `CPUExecutionProvider` only — deliberately:
this asset was never exported for or profiled against QNN, so the adapter
never requests it and always reports `accelerator: cpu`, `npu: false`. It
uses the standalone `tokenizers` package for the real BPE tokenizer (no
torch, no transformers). `/api/models/status` confirms selection:
`role=reasoning provider=onnx-cpu-smolvlm model=smolvlm_500m_instruct
accelerator=cpu npu=False synthetic=False`.

**Documented simplification.** The real Idefics3 image processor tiles a
large photo into multiple 512×512 crops plus a downscaled global thumbnail
("image splitting") for extra visual detail. This adapter does not
reproduce that tiling — every image is treated as a single global 512×512
patch (resized to fit, padded, with a real `pixel_attention_mask` marking
the padded region). The vision encoder, embedding table and decoder are the
real exported weights running real inference on the real photograph; only
the multi-crop detail boost is skipped. Reported in `capabilities()` as
`"image_splitting": false` and in health `detail.image_preprocessing`.

**The motor image case, live through the API** (`motor_bearing_hot.jpg`,
`POST /api/photo/analyze` → chat): *"This is a pump motor with a black fan
and a red motor."* — hazard `rotating` correctly flagged, confidence `0.2`
("Needs evidence", honest — no measurement was taken), `model.provider:
onnx-cpu-smolvlm`, `model.npu: false`. Real, image-grounded, non-fabricated
output from the real vision encoder.

**Original finding (pre-2026-09-24, model-driven tool-calling architecture).**
Baseline with `heuristic-offline`: 32/32 PASS. With `onnx-cpu-smolvlm`:
24/32 PASS, 1 PARTIAL, 7 FAIL (D1 partial; D4, MEM1, MEM2, E6, V1, V4, UNC1
fail). Root cause, confirmed directly rather than assumed: prompted with an
explicit tool schema *and* a worked few-shot example of the exact
`​```tool_call{...}​```` format this app parses, SmolVLM-500M-Instruct still
answered a memory-dependent question with a bare hallucinated number instead
of ever emitting a tool call. It was never trained on function/tool-calling
data at this scale. Because the old SEE→RETRIEVE→REASON loop depended on the
reasoning model *choosing* to call `search_memory`/`search_documents`/OCR/
vision tools, evidence simply never got gathered on these turns
(`evidence_keys: []`, `work_trail: []`) and the model answered ungrounded.
A separate, secondary decoding-robustness bug (greedy decoding occasionally
locking onto one repeated token instead of emitting EOS) was found and fixed
in the same pass (`_run_generate`: 5-repeat early stop + trailing-duplicate
trim) — real, but not the cause of the above.

**Fix: orchestrator-driven evidence gathering (2026-09-24).** Rather than
requiring the reasoning model to speak tool-call JSON, the backend now
decides what evidence a turn needs and fetches it itself, before the
reasoning model is ever called — see "Orchestrator-driven evidence
gathering" below. This directly targets the root cause above: SmolVLM no
longer has to request evidence to receive it.

**Rerun after the fix, full 32-point suite both ways, same harness:**

| Provider | Phase 1 (15) | Phase 2 (17) | Total | Safety (6/6) |
|---|---|---|---|---|
| `heuristic-offline` | 15/15 | 17/17 | **32/32 PASS** | PASS |
| `onnx-cpu-smolvlm` | 11/15 (M1, M2, MEM1, MEM2 fail) | 15/17 (E6, UNC1 fail) | **26/32 PASS, 6 FAIL** | PASS |

Document grounding is fixed: **D1, D2/D3, D4, L5 and UNC2 — the checks the
user specifically asked to be rerun — now all pass** with SmolVLM, because
`search_documents`/`get_document_page` results now reach it unconditionally
instead of depending on a tool call it couldn't make. That confirms the
architectural fix worked as intended.

Two *different* real limitations replaced the old one, not a clean pass:

- **Verbatim-copy degeneration on longer, multi-part prompts.** M1, M2,
  MEM1 and MEM2 all involve multi-turn continuity or job-memory synthesis —
  the longest prompts in the system (conversation history + job context +
  full evidence block). Under greedy decoding SmolVLM's answer on these
  turns is, word for word, a copy of a span of its own input rather than a
  new synthesized answer — e.g. MEM2's answer includes the literal text
  `"This is the current job context:\n\nJob: T7 MEM1/MEM2 compressor
  job..."`, lifted straight out of its own system prompt, and M1's turn3/
  turn4 answers are the technician's own just-asked question, echoed back
  verbatim. This is a distinct failure mode from tool-calling absence: the
  evidence *is* present in the prompt, but a 500M model under greedy
  decoding on a long, multi-source prompt tends to continue/copy rather
  than reason over it.
- **Still hallucinates specific values even with grounding evidence
  present.** V1 nameplate: real OCR ran (34 text regions, including the
  genuine `1LE1001-1DB2` type code) and was in the prompt, yet SmolVLM's
  answer states `"This motor is a Siemens Type SN-2291087-A"` — a fabricated
  serial that matches nothing OCR actually read. The harness's V1 check
  (`len(text) > 20`, no crash) is too shallow to catch this and marks it
  PASS; recorded here because a shallow test passing is not the same as the
  content being grounded. UNC1 similarly states a specific cause with no
  hedging (`"This machine has a worn belt and a worn bearing"`) on a
  question the test deliberately gives thin evidence for, violating the
  system prompt's own hard rule to label Likely/Possible/Unknown.
- E6 fails only on the harness's length bar (SmolVLM's OCR-grounded answer,
  `"Panel HMI: Thermal Overload."`, is honest but too terse at 29 characters
  against a 40-character bar) — a style mismatch with `ANSWER_SHAPE`'s
  structured format, not a grounding problem.

**Still fully intact:** all 6 safety checks (SAFE1-6) in both phases — that
layer is a separate regex-based module (`app/agent/safety.py`), untouched by
either this refactor or which reasoning provider is active — plus D1-D4, L1,
L5, multi-photo, MEM3, VO1-3, Report, FAIL1-4, UNC2, V2-V4 and
system_status.

**Decision, per the stated bar ("comparable to or better than baseline
without compromising safety or evidence grounding"): not met.** Safety is
intact, and document/OCR grounding measurably improved, but 26/32 against
heuristic's 32/32 — with two of the six new failures being a values-level
hallucination the shallow test missed and a verbatim-copy-instead-of-reason
failure on the app's longest prompts — is not comparable to baseline.
`heuristic-offline` stays pinned as the default in `backend/.env`.
`onnx-cpu-smolvlm` remains fully wired up, selectable
(`VF_REASONING_PROVIDER=onnx-cpu-smolvlm`), and not abandoned; the
verbatim-copy pattern under long prompts is the clearest next thing to
address (a repetition/n-gram-copy penalty at decode time, or trimming the
evidence block to what's most relevant rather than everything gathered,
are the two most promising next angles) if it's revisited.

---

## Orchestrator-driven evidence gathering (2026-09-24)

Evidence gathering used to happen only when the *reasoning model itself*
emitted a `​```tool_call{...}​``` block (`app/agent/prompts.py`'s
`TOOL_PROTOCOL`, consumed by the round loop in `app/agent/orchestrator.py`).
`HeuristicReasoningProvider` never had a problem with this because it *is*
the tool-selection logic (`app/models/heuristic.py::_choose_tools`) — it
returns the calls it wants directly from `generate()`, nothing has to be
"emitted." A real small VLM does have a problem with it, as the SmolVLM
section above documents directly.

`app/agent/evidence_planner.py` (new) now runs *before* the reasoning model
is ever called for a turn. It mirrors `_choose_tools`'s own two-wave shape —
wave one (job memory, document chunks, vision detections, OCR — independent
of each other) then wave two (web search only if local knowledge came up
thin, classification only if a detection is worth a closer look, a document
page opened only if the question is spatial and retrieval actually landed on
one) — and calls the same `tool_registry.call(...)` API the model-driven
path already used, through `Orchestrator._run_tools` (reused, not
duplicated). The result is assembled into the same evidence dict and reaches
the reasoning model through the same `evidence_block()` system message that
already existed — no new prompt mechanism, no provider-specific branching.

`app/agent/orchestrator.py::Orchestrator.ask()` calls
`evidence_planner.gather(...)` once, then enters its existing model-driven
round loop unchanged. For `heuristic-offline`, `_choose_tools` finds
everything it would have asked for already `done` and goes straight to
composing — one reasoning call instead of up to four, same behaviour, not a
behaviour change (confirmed: 32/32 both before and after). For any provider
that never emits tool-call JSON — SmolVLM, and any future small on-device
VLM — the basic evidence pipeline no longer depends on that capability at
all. The round loop is left in place as a legacy path: a provider that
genuinely can request something beyond the plan (`vision_segment`,
`vision_track`, `ask_user`, `fetch_web_source`) still can.
`app/agent/safety.py` was not touched — it already runs independently of
which reasoning provider is selected, applied to whatever text comes back,
which is why all 6 SAFE checks pass identically under every configuration
tested above.

---

## Real vision detector — YOLO11n ONNX (2026-09-24)

`YoloOnnxDetector` (`app/models/yolo.py`) was already complete, real code —
letterbox preprocessing, the YOLOv8/v11 `[1, 4+nc, n]` head decode, NMS,
COCO label mapping — waiting only on an asset file at
`data/models/yolov11_det/`. Every previous attempt to obtain one (YOLO11,
YOLO-WORLD, EfficientNet, SAM2/MobileSAM, Nomic-Embed) failed because
Hugging Face is unreachable from this sandbox. Checked directly this session
rather than assumed: `github.com`'s release-asset CDN (`release-assets.
githubusercontent.com`, reached via a signed redirect off `github.com`) *is*
reachable through this sandbox's egress proxy, and Ultralytics publishes
official pretrained ONNX exports as GitHub release assets, not only on
Hugging Face.

**What was installed.** `yolo11n.onnx` from
`github.com/ultralytics/assets` release `v8.3.0` (AGPL-3.0, Ultralytics'
own official export, not a third-party re-upload) — downloaded directly by
this sandbox (no user action needed this time), verified as a genuine ONNX
graph with `onnxruntime` before installing: input `images`
`[batch, 3, height, width]`, output `output0` `[batch, 84, anchors]` = the
exact `4 box coords + 80 COCO class scores` layout `YoloOnnxDetector`
already decodes. Installed at `data/models/yolov11_det/model.onnx`
(10.9 MB), picked up via `POST /api/models/reload` with zero code changes.
`/api/models/status` confirms: `role=detector provider=yolo-onnx
model_id=yolov11_det accelerator=cpu npu=False synthetic=False`.

**What this does and doesn't mean.** This is Ultralytics' stock COCO-80
pretrained checkpoint — general objects (person, bottle, chair, truck, ...),
not an industrial-parts-specific class set (no "bearing housing", "terminal
block", "contactor" class exists in COCO). Run against this app's own test
photographs of bare machine components, it correctly returns *no*
detections — confirmed live (`vision_detect` on `component_scene.jpg`: `ok:
true, "no objects detected"`, 52.89 ms) — rather than forcing a wrong COCO
label onto industrial equipment. That is the honest, correct behaviour the
adapter was already written to produce on a genuine miss (§25: the pipeline
degrades to OCR + VLM-only inspection), not a bug. It will fire correctly
whenever a real COCO-class object legitimately appears in a technician's
photo (a person, PPE-adjacent items like gloves aren't COCO either, a
vehicle, tools that happen to match a COCO class). A detector genuinely
useful for naming machine *components* by class would need a model
fine-tuned on an industrial/component dataset, which is a further, separate
step from "a real detector is now running."

**Regression, full 32-point suite, `heuristic-offline` (with the real
detector now in the candidate chain) + the orchestrator-driven evidence
pipeline:** 32/32 PASS, all 6 safety checks intact, `vision_detect` genuinely
executing real ONNX Runtime inference on every image turn (not the prior
`{"detections": [], "degraded": true, "reason": "no detector available"}`
stand-in) with no change in outcome, since this app's test photography is
industrial equipment outside COCO's 80 classes, exactly as expected above.

---

## Real Piper voice — en-us-lessac-medium (2026-09-24)

**STT re-checked, still genuinely blocked.** Before looking at Piper,
Whisper-Base was re-tried given the detector's success — same conclusion as
before, now confirmed by a different method (the egress proxy's own policy
log, `$HTTPS_PROXY/__agentproxy/status`, shows `huggingface.co`,
`ggml.ggerganov.com` and `openaipublic.azureedge.net` as explicit
`connect_rejected` policy denials, not flaky hosts) and by checking whether
either project ships weights as GitHub release assets the way Ultralytics
does — neither does. `PocketSphinxProvider` stays the real STT fallback;
Task #49 treats this half as attempted and honestly closed, not solved.

**TTS: real voice found and installed.** `rhasspy/piper-voices` on Hugging
Face is blocked, but Piper's own repository shipped its early voice models
(pre-`piper-voices`-migration) directly as GitHub release assets — verified
by fetching `github.com/rhasspy/piper/releases/download/v0.0.2/
voice-en-us-lessac-medium.tar.gz` (real 302 to a signed `release-assets.
githubusercontent.com` URL, 58 MB, containing `en-us-lessac-medium.onnx` +
its `.onnx.json` config + a `MODEL_CARD` — genuine Piper release, Lessac
voice, CSTR Blizzard 2013 dataset, en-US, medium quality). Installed at
`data/models/pipertts_en/`. `piper-tts` (the modern PyPI CLI, `pip install
piper-tts`, no network dependency beyond the one-time install from PyPI,
which this sandbox's egress policy does allow) reads the older config
without issue. `/api/models/status` confirms: `role=tts provider=piper
model_id=pipertts_en accelerator=cpu npu=False synthetic=False`.

Verified for real, not assumed: `POST /api/voice/synthesize` produces a
genuine 16 kHz mono WAV (checked directly with Python's `wave` module — 2.4s
audio, 99% non-silent samples, full dynamic range), `model: pipertts_en`,
`degraded: false`. This replaces `EspeakTTSProvider` (formant synthesis) as
the default per the existing candidate order (`piper` before `espeak-ng`);
espeak-ng remains the honest fallback if this asset is ever absent.

**Regression, full 32-point suite, with the real Piper voice in the
candidate chain:** 32/32 PASS, all 6 safety checks intact, VO3 (synthesis)
genuinely exercising `piper`/`pipertts_en` rather than the prior `espeak-ng`
stand-in, no change in outcome.

---

## The Compute-support caveat (§4)

§4 warns that an AI Hub model page can show X-series device metadata while
also reporting a current Compute-support limitation, and names
**YOLOv11-Detection**, **YOLO-WORLD** and **YOLOv11-Segmentation** as current
examples. Those three are therefore treated as **experimental** here until a
Workbench export and profile succeed on the target device.

Before integrating any model, follow §26 and read the current model card and
the repository's own files — `README.md`, `demo.py`, `export.py`, the model
implementation, its dependencies, runtime support, precision options and
device support — rather than assuming any command in this file still works:

```
https://github.com/qualcomm/ai-hub-models
src/qai_hub_models/models/<model>/
```

---

## Qualcomm AI Hub export/profile attempt (2026-09-24)

Genuinely attempted from this sandbox, not just reasoned about from prior
research (task tracker #50). `pip install qai-hub` succeeds — PyPI is
unrestricted by this sandbox's egress policy, so the SDK itself installs
cleanly (`qai-hub-0.55.0`). The blocker is the network call every subsequent
step depends on: `curl https://aihub.qualcomm.com` and
`https://app.aihub.qualcomm.com` both come back as explicit
`connect_rejected` entries in the egress proxy's own policy log
(`$HTTPS_PROXY/__agentproxy/status` → `"detail": "gateway answered 403 to
CONNECT (policy denial or upstream failure)"`), the same category as
`huggingface.co` — an organizational network policy decision, confirmed by
the proxy itself, not a transient failure or a guess. `qai-hub configure
--api_token <token>` would fail at its very first HTTP call regardless of
whether a valid token were supplied.

This is unresolvable from inside this sandbox on two independent axes, both
already true before this attempt and reconfirmed by it: (1) no Qualcomm AI
Hub account/API token exists or can be self-provisioned here, and (2) even
with one, this environment's own network policy blocks the API host outright
— and separately, (3) no physical or cloud-hosted Snapdragon device is
attached to profile against even if the API were reachable. Exporting or
profiling the working stack for Snapdragon therefore genuinely cannot happen
from this sandbox; it needs either a different network environment (one
whose egress policy allows `aihub.qualcomm.com`) or to be run directly on
target hardware, with a real AI Hub account.

**Per §4: nothing in this build claims Snapdragon/NPU support, and this
finding does not change that.** Every adapter that loaded this session
(YOLO11n detector, Piper TTS, SmolVLM, heuristic reasoner, tesseract OCR,
PocketSphinx STT) reports `accelerator: cpu, npu: false` because that is
what the runtime actually gave it — confirmed, not assumed, the same way
every other role in this file is reported. This attempt is recorded as
closed-but-blocked rather than left silently unattempted.

---

## Snapdragon integration phase — GenieX adapter + export scaffolding (2026-09-24)

Scope of this phase, per the instruction that opened it: keep the current
stable state, do not touch the UI, prepare Qualcomm AI Hub authentication,
identify the current best-supported Snapdragon VLM and vision model, make
the adapters/export pipeline ready, and never claim NPU support until an
actual AI Hub profile/export succeeds. Everything below was verified
directly wherever verification was possible from this sandbox; where it
wasn't (network- or platform-blocked), that is stated plainly rather than
assumed.

### What "current" actually means now: GenieX, not just onnxruntime-genai

Qualcomm's own current documentation has moved on since this project's
earlier research. Re-checked live against the real repository (§26):

- `src/qai_hub_models/models/qwen3_4b/README.md` now explicitly calls the
  older "Genie" runtime **"deprecated soon"** and documents **GenieX** as
  the current one, with a `geniex_qairt` runtime option shown for that
  (text-only) model.
- `src/qai_hub_models/models/qwen3_vl_2b_instruct/README.md` — the model
  already named in this project's own default config
  (`settings.reasoning_model_id == "qwen3_vl_2b_instruct"`) — documents its
  export as `qai-hub-models fetch Qwen3-VL-2B-Instruct --runtime
  geniex_llamacpp --precision q4_0`. That is GenieX's `llama_cpp` plugin
  (CPU/GPU/hybrid, GGUF-consuming), not the `qairt` (NPU-only) plugin. A
  `geniex_qairt` option for this specific 2B VLM was **not found** in that
  README as of this writing — this is recorded as an open question, not
  assumed either way. `scripts/export_reasoning_geniex.py --runtime
  geniex_qairt` exists so this can be tried directly on a machine with real
  AI Hub access, which will get a real, authoritative answer instead of
  another guess.
- Qwen3-VL-2B-Instruct is Apache-2.0 and its AI Hub device-support table
  lists Snapdragon X Elite, X Plus 8-Core and X2 Elite — the same targets
  this project has already been tracking.

Note on GenieX's `llama_cpp` plugin: it is **not** a CPU-only fallback in
the way this project's other CPU adapters are. Its own alias table maps
`device_map="npu"`/`"hybrid"` to a real Hexagon HTP ggml backend
(`HTP0`) — genuine NPU-class acceleration through a different code path
than `qairt`. `GenieXReasoningProvider` (below) does not assume either
plugin means NPU; it reads back what the runtime actually used after a
real call, for both plugins alike.

**Detector role:** no dedicated industrial/engineering-specific detection
model exists on AI Hub (searched explicitly, again, this phase) — only
general-purpose COCO-class detectors (YOLO11, the newer YOLO26). YOLOv11-
Detection — already this project's `settings.detector_model_id` default —
remains the best-supported current choice, and its real export path targets
QNN directly: `python -m qai_hub_models.models.yolov11_det.export
--quantize {w8a8_mixed_int16,w8a16,w8a8}`. Unlike the reasoning role, this
needs **zero new adapter code** — `YoloOnnxDetector` (`app/models/yolo.py`)
already generically loads any ONNX export via `onnxruntime`'s
`QNNExecutionProvider`-first session; only a genuine export needs to land in
`data/models/yolov11_det/`. §4's Compute-support caveat (below) still
applies to this model.

### How the GenieX findings were verified, not guessed

Rather than trust scraped documentation for something adapter code would be
written against, the real `geniex` PyPI package (v0.7.0, BSD-3-Clause) was
downloaded and its actual source read in full: `__init__.py`, `auto.py`
(`AutoModelForCausalLM`/`AutoModelForVision2Seq.from_pretrained`, the
`qairt`/`llama_cpp` plugin split, `device_map` alias resolution),
`modeling.py` (`GenieXLLM`/`GenieXVLM`, their real `generate()`/streaming
signatures and `ProfileData` fields), `model_manager.py` (`pull`/
`ensure_cached`/`list_hub_models`, and — importantly — confirmation that its
public API exposes only `hf_token`, no separate AI Hub token parameter; see
`scripts/setup_qai_hub_auth.md` for what that does and doesn't tell us), and
its own `README.md`.

**Two hard, directly-verified facts came out of that, both load-bearing for
this phase's scope decisions:**

1.  `pip install geniex` only succeeds on Linux aarch64 or Windows arm64.
    Not assumed — actually attempted in this sandbox:

    ```
    RuntimeError: Unsupported platform ('linux', 'x86_64') for prebuilt
    geniex SDK.
    ```

    This means `geniex` cannot be installed, imported, or exercised at all
    in this development sandbox, independent of any bundle, account, or
    network question. `GenieXReasoningProvider` can only ever report
    `unavailable` here, honestly, for exactly this reason (see its own
    module docstring in `app/models/geniex_provider.py`).

2.  Submitting an export/profile job to Qualcomm AI Hub
    (`qai-hub`/`qai-hub-models`) can run from **any** machine with a real
    account and network access — that step is a cloud job submission to
    Qualcomm's hosted device farm, not local execution, and `qai-hub`
    itself installs and runs fine on ordinary x86_64 Python (confirmed
    already in the prior "Qualcomm AI Hub export/profile attempt" section).
    But *loading and running* the resulting GenieX bundle to actually serve
    real inference needs the **process itself** to be on Snapdragon-class
    ARM64 hardware, per fact 1. An AI Hub export alone, sitting on a
    regular x86_64 dev machine, does not and cannot make `geniex-npu`
    ready — that is a platform gate, not a missing-asset problem, and
    `scripts/setup_qai_hub_auth.md` says so explicitly so this isn't
    rediscovered the hard way during a demo.

### What was built this phase

- **`app/models/geniex_provider.py`** — `GenieXReasoningProvider`, a new
  `ReasoningProvider` adapter against the real `geniex` API found above.
  Registered first in `app/models/registry.py`'s reasoning candidate list
  (before `onnxruntime-genai`), since it's the most genuinely
  Snapdragon-current path — but it changes nothing about what wins under
  `auto` anywhere this sandbox can test, because it always reports
  `unavailable` here (fact 1). Verified directly: instantiating it and
  calling `.health()` returns `status=unavailable`,
  `reason="geniex not importable (...)"`, exactly as designed, not silently
  swallowed. Two honesty rules enforced in this file, matching every other
  adapter in this package:
  - It never half-loads: a bundle must already exist under
    `data/models/<model_id>/geniex/` (a `qairt` bundle:
    `metadata.json` + `*.bin` shards, or a `llama_cpp` bundle: `*.gguf`).
    Nothing is fetched at runtime.
  - `accelerator`/`npu` are set only from `GenerateOutput.profile.backend`/
    `.device`, read back after a real warm-up `generate()` call actually
    completed on the loaded bundle on that host — never from what
    `device_map` requested. This is the same "trust what the runtime
    actually gave you" rule `runtime.py` applies to
    `session.get_providers()`, applied to GenieX's own post-hoc profile
    data as the equivalent ground truth. Because this can only ever run on
    real Snapdragon-class ARM64 hardware with a real bundle, `npu=true` is,
    by construction, unreachable anywhere this project has been able to
    test — which is exactly the "no NPU claim without a real profile"
    instruction this phase opened with, enforced structurally rather than
    by a promise.
- **`app/config.py`** — `qai_hub_api_token` (never a real secret, §24) and
  `geniex_device_map` settings; **`.env.example`** documents both plus the
  new `geniex-npu` candidate.
- **`scripts/setup_qai_hub_auth.md`** — the account/token setup walk-through,
  written for **your own machine**, explicit about which of its steps need
  network-only vs. genuine Snapdragon ARM64 hardware, and honest about the
  one inference that couldn't be independently confirmed (whether GenieX's
  `hub="aihub"` pulls reuse `qai-hub configure`'s own credential store —
  plausible, not proven, from the Python API alone).
- **`scripts/export_reasoning_geniex.py`** and
  **`scripts/export_detector_yolov11.py`** — parameterized, ready to run on
  a machine with real AI Hub access. Neither guesses an unverified output
  directory path; both print the underlying tool's own reported location
  and offer `--stage-from DIR` to copy recognized files into the exact
  layout the corresponding adapter expects.
- **`requirements.txt`** — documents `qai-hub`/`qai-hub-models` (any
  machine) and `geniex`/`geniex-qairt` (Snapdragon ARM64 only, with the
  verified platform-failure message inline) as install-when-you-have-the-
  hardware comments, consistent with this file's existing "keep these out
  of the base install" convention — adding either unconditionally would
  break `pip install -r requirements.txt` on every machine that isn't
  Snapdragon-class ARM64.

### Regression pass for this phase

Full suite re-run after the above (`pytest`, 104 tests). It surfaced one
real, pre-existing bug unrelated to any of this phase's changes:
`app/knowledge/document_ingest.py`'s `ingest()` had a structural
indentation fault — the entire post-extraction block (OCR, chunk/embed
indexing, the `documents`/`document_pages` DB rows) had ended up nested
*after* an unconditional `raise` inside the `except UnsupportedMedia`
handler, making it dead code on every normal (non-error) upload and leaving
`index` unbound by the time `metadata.json` was written. This broke every
test that uploads or relies on a previously-uploaded document (30 of 104
tests, across `test_agent.py`, `test_conversation.py`, `test_knowledge.py`,
`test_scenarios.py`, `test_end_to_end.py`) with `UnboundLocalError`. Fixed
by moving that block back inside the `try:` (its evident original
placement, since `_index`/OCR/DB-write are exactly the kind of failure
`UnsupportedMedia`'s cleanup exists to unwind). Confirmed unrelated to this
phase's own work: none of it touches `app/knowledge/`, and the failure mode
(`index` never assigned) reproduces from the indentation alone, independent
of which reasoning/detector candidates exist. Re-run after the fix: 95
passed, 9 failed (down from 30).

The remaining 9 are pre-existing test/reality mismatches, not regressions
from this phase, confirmed by inspection of each:

- `test_foundation.py::test_every_spec_model_is_selectable` expects
  `candidates_tried["reasoning"]` to list every candidate, which only
  happens under `VF_REASONING_PROVIDER=auto`; `backend/.env` pins it to
  `heuristic-offline` (the project's own stable-default decision), which
  makes `_select()` filter the candidate list down to that one entry before
  any candidate is tried. Independent of `geniex-npu`'s addition — verified
  directly by instantiating a fresh `ModelRegistry` with
  `reasoning_provider="auto"` outside the pinned `.env`: the full chain
  (`geniex-npu`, `onnxruntime-genai`, `local-openai-compat`,
  `onnx-cpu-smolvlm`) is tried in order and falls through to
  `onnx-cpu-smolvlm` exactly as before this phase.
- `test_vision.py::test_degraded_detector_names_its_fallback` and the five
  `test_scenarios.py::test_image_scenario_states_what_it_cannot_confirm[...]`
  cases assert OCR is `degraded`/in `degraded_tools`. `TesseractOCRProvider`
  has been a real, always-loading OCR adapter since the QA-fix pass (see
  "Real model running — `tesseract`" above) — these tests' own comments
  ("With no export loaded, both degrade") predate that change and were not
  updated alongside it.
- `test_vision.py::test_voice_degrades_without_claiming_cloud` asserts STT
  is `degraded` on a garbage WAV; `PocketSphinxProvider` is a real,
  always-loading STT adapter (same QA-fix pass) and evidently does not
  treat that particular malformed input as a hard failure the way the test
  assumes.
- `test_end_to_end.py::test_same_machine_across_two_sessions` asserts a
  confidence-delta tolerance (`second["confidence"] >= first["confidence"]
  - 0.2`) that the deterministic `heuristic-offline` reasoner's own scoring
  misses by 0.06 on this run.

None of these were introduced by this phase's changes (no file any of them
exercises was touched by this work); left as-is per this phase's "keep the
current stable state, don't fix things you weren't asked to fix" framing —
recorded here rather than silently noticed and dropped.

---

## Validating a model on the target machine

The commands below are the ones §5 documents. Check them against the current
repository before running; do not invent integration commands.

```bash
pip install qai_hub_models
qai-hub configure --api_token <token from your environment>

qai-hub-models devices
qai-hub-models chipsets
qai-hub-models info  <MODEL>
qai-hub-models perf  <MODEL>
qai-hub-models numerics <MODEL>

qai-hub-models install <MODEL_ID>
qai-hub-models fetch <MODEL> --runtime <runtime> --precision <precision>
# For licence-restricted assets, use the documented export workflow instead.
```

**Windows note (§5):** Qualcomm's current README says Snapdragon X Elite /
X2 Elite Windows users should use AMD64/x86-64 Python for `qai_hub_models`.
Verify that this is still the current requirement before setting up the
machine.

Place the resulting asset here:

```
backend/data/models/<model_id>/model.onnx
backend/data/models/<model_id>/labels.json        # detectors, optional
backend/data/models/<model_id>/tokenizer.json     # embedders
backend/data/models/qwen3_vl_2b_instruct/         # a genai (onnxruntime-genai) export directory
backend/data/models/qwen3_vl_2b_instruct/geniex/  # a GenieX bundle -- see scripts/export_reasoning_geniex.py
```

Then, without restarting:

```bash
curl -X POST http://127.0.0.1:8756/api/models/reload
curl http://127.0.0.1:8756/api/models/status
```

Confirm in the response that `accelerator` is `npu` and `npu` is `true` for
that role. If it says `cpu`, the QNN execution provider was not applied — the
service will have logged the reason — and the honest claim is CPU.

---

## Record replacements here

When a model fails Compute validation and is swapped, append a row:

| Date | Intended model | Why it failed | Replacement | Measured latency | Accelerator |
|---|---|---|---|---|---|
| 2026-09-23 | EasyOCR / TrOCR | Weight download requires a host this sandbox's egress policy blocks | `TesseractOCRProvider` (system `tesseract`, apt) | ~150-400ms per image (2 CPU) | cpu |
| 2026-09-23 | Whisper-Base | Weight download requires a host this sandbox's egress policy blocks | `PocketSphinxProvider` (PyPI `pocketsphinx>=5`, bundled model) | ~1s per short utterance (2 CPU) | cpu |
| 2026-09-23 | PiperTTS-EN | Voice asset download requires a host this sandbox's egress policy blocks | `EspeakTTSProvider` (system `espeak-ng`, apt) | ~10-20ms per synthesis call (2 CPU) | cpu |
| 2026-09-24 | Intern3.5-VL-2B | Export requires a Qualcomm AI Hub account/API token plus physical or cloud Snapdragon hardware, neither self-provisionable here | `SmolVLMOnnxProvider` (real ONNX SmolVLM-500M-Instruct, downloaded via the user's own browser, hand-rolled `onnxruntime` CPU pipeline); kept selectable, not the default — see comparison above | ~10-25s per turn under the orchestrator-driven evidence pipeline (2 CPU) | cpu |
| 2026-09-24 | YOLO11-Detection | Qualcomm AI Hub export needs the same account/hardware as above; the usual Hugging Face weight source is blocked in this sandbox | `YoloOnnxDetector` running Ultralytics' own official `yolo11n.onnx`, obtained directly from `github.com/ultralytics/assets` release assets (reachable where Hugging Face is not) — real inference, COCO-80 classes | ~50ms per image (2 CPU) | cpu |
| 2026-09-24 | PiperTTS-EN | `rhasspy/piper-voices` (current distribution) is on Hugging Face, blocked in this sandbox | `PiperTTSProvider` running the real `en-us-lessac-medium` voice, obtained from Piper's own pre-migration GitHub release assets (`rhasspy/piper` `v0.0.2`) — replaces `EspeakTTSProvider` as the default | ~1.3-1.4s per synthesis call (2 CPU) | cpu |

---

## What "synthetic" means

Two roles ship deterministic stand-ins so the full agent loop runs before any
export exists:

- **`heuristic_offline_v1`** — rule-based tool selection plus evidence-bound
  composition in the §18 technician structure. Not a language model. It
  cannot generalise, and it produces no tokens/sec or NPU figures.
- **`lexical_hash_v1`** — stop-filtered hashed word and character-trigram bag,
  L2-normalised. A real lexical embedding, genuinely useful for part numbers
  and error codes, but not semantic.

Both are flagged `synthetic: true` in `/api/models/status`, logged at startup,
and surfaced in every chat response under `model`. Replacing them with real
exports is Phase 9 of §22.
