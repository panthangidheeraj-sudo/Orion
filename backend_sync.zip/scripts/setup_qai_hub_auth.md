# Setting up Qualcomm AI Hub authentication

Snapdragon integration phase (§4, 2026-09-24). This is a **run-it-yourself**
doc, not a script you can fire from this dev sandbox — the sandbox's own
egress policy blocks `aihub.qualcomm.com` and `app.aihub.qualcomm.com`
outright (verified directly, not assumed: see MODEL_STATUS.md, "Qualcomm AI
Hub export/profile attempt"), and `geniex` (the runtime that actually loads
a GenieX bundle) only installs on Linux aarch64 / Windows arm64, which this
sandbox is not (verified directly too — see that same section). Everything
below runs on **your own machine**, wherever that has both real network
access and, for the parts that matter, real Snapdragon hardware.

There are two separate concerns here. Keep them separate, because they need
different machines:

| Step | What it needs | Can run on |
|---|---|---|
| 1. Get an AI Hub account + API token | A browser, a Qualcomm ID | Any machine |
| 2. `qai-hub configure` + `qai-hub-models fetch/export/profile` | Network to `aihub.qualcomm.com`, an API token | Any machine — this submits jobs to Qualcomm's hosted device farm, it does not run the model locally |
| 3. Actually loading the exported bundle through `geniex` to serve real inference (this app's `geniex-npu` adapter) | Linux aarch64 or Windows arm64 — i.e. an actual Snapdragon device | **Only Snapdragon-class ARM64 hardware.** Confirmed as a hard platform gate, not a missing-package issue — see below. |

Step 3 is the one that matters for `GET /api/models/status` to ever show
`geniex-npu` as `ready`. Steps 1-2 alone get you an export artifact, not a
running NPU adapter.

---

## 1. Create a Qualcomm AI Hub account and get an API token

1. Go to `https://aihub.qualcomm.com` in a browser and sign in / create an
   account (a Qualcomm ID).
2. Once signed in, find your API token under your account/profile settings
   on the AI Hub site — the exact page has moved before, so use the site's
   own account/settings navigation rather than a URL guessed here.
3. Copy the token somewhere safe. **It is a secret.** Never commit it, never
   put it in `backend/.env.example`, never paste it into a chat, a script
   argument that gets logged, or a file under version control. Per §24 of
   this project's spec, the only place it belongs is your local
   `backend/.env` (already gitignored — verify that before pasting) or your
   shell environment.

## 2. Configure `qai-hub` locally

On the machine that will submit export/profile jobs (any machine with
network access — does **not** need to be Snapdragon hardware):

```bash
pip install qai-hub qai-hub-models
qai-hub configure --api_token "$VF_QAI_HUB_API_TOKEN"
```

`backend/.env.example` documents `VF_QAI_HUB_API_TOKEN` as the place this
project expects the token to live if you want to source it from the
backend's own `.env` rather than typing it inline. The running backend
service itself never reads or calls this token at runtime — nothing in
`app/` makes an AI Hub network call — this variable exists purely so this
setup step and the export scripts below have one documented place to read
it from, per §24 ("API keys never live in source code — only in the local
environment").

Verify it worked:

```bash
qai-hub-models devices
qai-hub-models chipsets
```

If these list real device/chipset names instead of erroring, the token is
live.

**On `geniex`'s own model manager** (`geniex.model_manager.pull(...,
hub="aihub")`, used by `scripts/export_reasoning_geniex.py` below): its
public Python API takes only `hf_token`, with no separate AI Hub token
parameter (confirmed by reading the real `geniex` v0.7.0 package source —
see MODEL_STATUS.md). The most plausible reading, consistent with both
tools being Qualcomm's own and `qai-hub configure` being the documented way
to authenticate any Qualcomm AI Hub client, is that the native SDK picks up
the same credential `qai-hub configure` writes to `~/.qai_hub/client.ini` —
**this is a reasonable inference from the available evidence, not a
confirmed fact**, since nothing in the `geniex` Python source itself proves
it. If `hub="aihub"` pulls fail with an auth error despite step 2 above
having succeeded, that inference is wrong and geniex needs its own,
separately-documented credential path — check `geniex-py --help` and
`geniex.model_manager` docstrings on the machine where you hit the error,
since a newer `geniex` release may have added one.

## 3. Run the export scripts

See `scripts/export_reasoning_geniex.py` (Qwen3-VL-2B-Instruct, the
reasoning VLM role) and `scripts/export_detector_yolov11.py` (YOLOv11-
Detection, the detector role). Both are safe to run from any machine for
the AI Hub job-submission part; read each script's own header for exactly
what it does and does not need Snapdragon hardware for.

## 4. Loading the result

- **Detector (YOLOv11-Detection):** drop the exported `.onnx` (and
  `labels.json` if you have one) into `backend/data/models/yolov11_det/`.
  `YoloOnnxDetector` (`app/models/yolo.py`) already generically loads any
  ONNX export via `onnxruntime`'s `QNNExecutionProvider`-first session — no
  code change needed. This role does not need `geniex` at all, and
  `onnxruntime-qnn` (the QNN execution provider build) has its own platform
  requirements independent of geniex's — check the current
  `onnxruntime-qnn` PyPI page for what it supports before assuming Windows
  ARM64 is required here too.
- **Reasoning VLM (Qwen3-VL-2B-Instruct via GenieX):** drop the exported
  bundle into `backend/data/models/qwen3_vl_2b_instruct/geniex/` (a
  `metadata.json` + `*.bin` shards for the `qairt`/NPU plugin, or a
  `*.gguf` for the `llama_cpp` plugin). `GenieXReasoningProvider`
  (`app/models/geniex_provider.py`) loads it automatically on the next
  `/api/models/reload` or restart — **but only on a machine where `pip
  install geniex` itself succeeds**, i.e. Linux aarch64 or Windows arm64.
  Running the backend on an ordinary x86_64 Windows/Linux dev box, even
  with a perfect export sitting in that folder, will make this adapter
  report `unavailable` with the platform reason above — that is expected,
  not a bug, and the registry falls through to the next candidate exactly
  as designed.

Then, without restarting the service:

```bash
curl -X POST http://127.0.0.1:8756/api/models/reload
curl http://127.0.0.1:8756/api/models/status
```

Check `roles.reasoning.provider` — it only reads `"geniex-npu"` with
`npu: true` if the runtime itself reported the `qairt` plugin or an HTP
device after a real `generate()` call actually ran on that host. If it says
`cpu`, `unavailable`, or falls to a different provider, that is the honest
answer — see `roles.reasoning.candidates_tried` for exactly why, and
MODEL_STATUS.md for what §4 requires before any NPU claim is made anywhere
in this project.
