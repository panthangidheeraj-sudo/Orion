#!/usr/bin/env python3
"""Export/fetch Qwen3-VL-2B-Instruct for GenieX and stage it for the backend.

Snapdragon integration phase (§4, 2026-09-24). This is **not runnable from
this dev sandbox** -- confirmed directly, not assumed: `aihub.qualcomm.com`
is blocked by this sandbox's own egress policy, and even if it weren't,
loading the result requires `geniex`, which only installs on Linux aarch64 /
Windows arm64 (this sandbox is x86_64 Linux). Run this on a machine that has
both real network access to Qualcomm AI Hub and, ideally, is itself the
Snapdragon target device -- see scripts/setup_qai_hub_auth.md first.

What this script does:

1.  Shells out to the AI Hub CLI's own documented fetch command:

        qai-hub-models fetch Qwen3-VL-2B-Instruct \\
            --runtime geniex_llamacpp --precision q4_0

    (confirmed from the model's real current README at
    github.com/qualcomm/ai-hub-models,
    src/qai_hub_models/models/qwen3_vl_2b_instruct/README.md, as of
    2026-09-24 -- re-check that file before relying on this if time has
    passed, per §26).

    ``--runtime geniex_qairt`` (the genuine NPU-only plugin, as opposed to
    ``geniex_llamacpp``'s CPU/GPU/hybrid -- which also has its own NPU-
    capable ``hybrid``/``npu`` device aliases via llama.cpp's Hexagon ggml
    backend, see app/models/geniex_provider.py's module docstring) is
    offered as an option below, but its existence for *this specific 2B
    model* was not confirmed during this project's research -- the sibling
    text-only Qwen3-4B model README shows a ``geniex_qairt`` runtime, but
    the 2B VLM's README only documented ``geniex_llamacpp`` as of this
    writing. This script does not fabricate that answer: pass
    ``--runtime geniex_qairt`` and let ``qai-hub-models`` itself tell you
    whether it's supported.

2.  This step's *job submission* runs fine from any machine with network
    access to AI Hub -- it does not need Snapdragon hardware itself, it
    just asks Qualcomm's hosted device farm to do the compiling.

3.  It does NOT auto-stage the result into backend/data/models/ -- the
    exact output directory layout ``qai-hub-models fetch`` writes was not
    independently verified from this sandbox (network-blocked), so rather
    than guess a path and silently do the wrong thing, this script prints
    the command's own reported output location and gives you
    ``--stage-from DIR`` to copy recognized GenieX bundle files (
    ``metadata.json`` + ``*.bin`` for qairt, or ``*.gguf`` for llama_cpp)
    into the layout ``GenieXReasoningProvider`` expects:

        backend/data/models/<model-id>/geniex/

Usage:

    python scripts/export_reasoning_geniex.py --runtime geniex_llamacpp --precision q4_0
    # ... inspect where qai-hub-models fetch wrote its output, then:
    python scripts/export_reasoning_geniex.py --stage-from /path/to/fetched/output
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = "Qwen3-VL-2B-Instruct"
DEFAULT_MODEL_ID = "qwen3_vl_2b_instruct"  # matches settings.reasoning_model_id

BUNDLE_FILE_PATTERNS = ("metadata.json", "*.bin", "*.gguf", "mmproj*.gguf", "tokenizer*.json",
                        "tokenizer_config.json")


def do_fetch(args: argparse.Namespace) -> int:
    try:
        import qai_hub_models  # noqa: F401  # type: ignore
    except ImportError:
        print(
            "qai_hub_models is not installed here. Install it on THIS machine "
            "(any machine with network access -- does not need to be "
            "Snapdragon hardware for this step):\n\n"
            "    pip install qai-hub qai-hub-models\n"
            "    qai-hub configure --api_token <your token>\n\n"
            "See scripts/setup_qai_hub_auth.md.",
            file=sys.stderr,
        )
        return 1

    # The documented entry point is the `qai-hub-models` console script, not a
    # `-m` module path -- use it directly, and tell the user how to fall back
    # to the module form if that console script isn't on PATH.
    console_cmd = ["qai-hub-models", "fetch", args.model, "--runtime", args.runtime,
                    "--precision", args.precision]
    print(f"$ {' '.join(console_cmd)}")
    try:
        proc = subprocess.run(console_cmd, check=False)
    except FileNotFoundError:
        print(
            "'qai-hub-models' console script not found on PATH even though "
            "qai_hub_models imports -- your install may need "
            f"'python -m qai_hub_models fetch {args.model} --runtime {args.runtime} "
            f"--precision {args.precision}' instead; check "
            "'qai-hub-models --help' / 'python -m qai_hub_models --help' on this "
            "machine.",
            file=sys.stderr,
        )
        return 1
    if proc.returncode != 0:
        print(
            f"\nqai-hub-models fetch exited {proc.returncode}. Common real causes: "
            "no AI Hub token configured (run 'qai-hub configure --api_token ...' "
            "first), a network policy blocking aihub.qualcomm.com from this "
            "machine, or (if you passed --runtime geniex_qairt) that runtime "
            "genuinely not existing for this model -- qai-hub-models' own error "
            "message says which.",
            file=sys.stderr,
        )
        return proc.returncode
    print(
        "\nFetch finished. Look at the command's own output above for exactly "
        "where it wrote the bundle (this script does not guess that path), "
        "then run:\n\n"
        f"    python {Path(__file__).name} --stage-from <that directory>\n"
    )
    return 0


def do_stage(args: argparse.Namespace) -> int:
    src = Path(args.stage_from).expanduser().resolve()
    if not src.is_dir():
        print(f"--stage-from {src} is not a directory", file=sys.stderr)
        return 1

    dest = BACKEND_ROOT / "data" / "models" / args.model_id / "geniex"
    dest.mkdir(parents=True, exist_ok=True)

    found = []
    for pattern in BUNDLE_FILE_PATTERNS:
        found.extend(sorted(src.rglob(pattern)))
    found = sorted(set(found))
    if not found:
        print(
            f"No recognized GenieX bundle files ({', '.join(BUNDLE_FILE_PATTERNS)}) "
            f"found under {src}. Nothing staged -- check the fetch output layout "
            "by hand before re-running with the right --stage-from directory.",
            file=sys.stderr,
        )
        return 1

    for f in found:
        target = dest / f.name
        shutil.copy2(f, target)
        print(f"  copied {f.relative_to(src)} -> {target.relative_to(BACKEND_ROOT)}")

    has_qairt = (dest / "metadata.json").exists() and any(dest.glob("*.bin"))
    has_llama_cpp = any(dest.glob("*.gguf"))
    if not (has_qairt or has_llama_cpp):
        print(
            f"\nStaged {len(found)} file(s) to {dest}, but none of them form a "
            "complete bundle GenieXReasoningProvider recognizes (needs "
            "metadata.json + *.bin, or *.gguf). Check what was actually copied "
            "above against what qai-hub-models fetch produced.",
            file=sys.stderr,
        )
        return 1

    print(
        f"\nStaged a {'qairt' if has_qairt else 'llama_cpp'} bundle to {dest}.\n"
        "This only helps if this machine is itself Linux aarch64 or Windows "
        "arm64 (where `pip install geniex` can succeed) -- see "
        "scripts/setup_qai_hub_auth.md. Reload the backend:\n\n"
        "    curl -X POST http://127.0.0.1:8756/api/models/reload\n"
        "    curl http://127.0.0.1:8756/api/models/status\n"
    )
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", default=DEFAULT_MODEL,
                   help=f"AI Hub model name to fetch (default: {DEFAULT_MODEL})")
    p.add_argument("--model-id", default=DEFAULT_MODEL_ID,
                   help=f"Local data/models/<id>/ folder name to stage into (default: {DEFAULT_MODEL_ID})")
    p.add_argument("--runtime", default="geniex_llamacpp",
                   choices=["geniex_llamacpp", "geniex_qairt"],
                   help="GenieX plugin to target. geniex_qairt (NPU-only) is not confirmed "
                        "to exist for this model as of this writing -- see module docstring.")
    p.add_argument("--precision", default="q4_0", help="Quantization precision (default: q4_0)")
    p.add_argument("--stage-from", default=None,
                   help="Skip the fetch step and copy a GenieX bundle already fetched at this "
                        "path into backend/data/models/<model-id>/geniex/")
    args = p.parse_args()

    if args.stage_from:
        return do_stage(args)
    return do_fetch(args)


if __name__ == "__main__":
    raise SystemExit(main())
