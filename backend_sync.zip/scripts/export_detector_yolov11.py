#!/usr/bin/env python3
"""Export YOLOv11-Detection for Snapdragon and stage it for the backend.

Snapdragon integration phase (§4, 2026-09-24). Not runnable from this dev
sandbox -- `aihub.qualcomm.com` is blocked by this sandbox's own egress
policy (verified directly, see MODEL_STATUS.md). Run this on a machine with
real network access to Qualcomm AI Hub; unlike the GenieX reasoning path,
this role needs **no** Snapdragon-specific Python package to load the
result -- `YoloOnnxDetector` (app/models/yolo.py) is already a generic ONNX
Runtime consumer, so any machine that can run `pip install qai-hub-models`
can produce and stage this export, and any machine running the backend with
`onnxruntime` + `onnxruntime-qnn` installed can load it.

What this does:

    python -m qai_hub_models.models.yolov11_det.export \\
        --quantize w8a8_mixed_int16

(command confirmed from the model's real current README at
github.com/qualcomm/ai-hub-models,
src/qai_hub_models/models/yolov11_det/README.md, as of 2026-09-24 --
re-check that file before relying on this if time has passed, per §26).
``--quantize`` accepts ``w8a8_mixed_int16``, ``w8a16``, or ``w8a8``; the
README's export target list includes "TensorFlow Lite, ONNX Runtime, or
Qualcomm AI Engine Direct" (QNN) -- pass ``--target-runtime`` if the
installed qai_hub_models version exposes it and you want to pin ONNX
specifically rather than take its default.

§4's Compute-support caveat applies here too (see MODEL_STATUS.md): AI Hub's
own model page can list Snapdragon X-series device support while also
showing a current Compute-support limitation banner. Whether that blocks an
actual export/profile run is something only this script's real output can
answer -- it is not assumed here either way.

This script does not guess the export's output directory (not independently
verified from this network-blocked sandbox); it prints the command's own
reported location and offers ``--stage-from DIR`` to copy the resulting
``.onnx`` into the layout ``YoloOnnxDetector`` expects:

    backend/data/models/yolov11_det/model.onnx
    backend/data/models/yolov11_det/labels.json   (optional; COCO-80 is the
                                                     built-in default)

Usage:

    python scripts/export_detector_yolov11.py --quantize w8a8_mixed_int16
    # ... inspect where the export command wrote its output, then:
    python scripts/export_detector_yolov11.py --stage-from /path/to/export/output
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL_ID = "yolov11_det"  # matches settings.detector_model_id


def do_export(args: argparse.Namespace) -> int:
    try:
        import qai_hub_models  # noqa: F401  # type: ignore
    except ImportError:
        print(
            "qai_hub_models is not installed here. Install it on THIS machine "
            "(any machine with network access -- this step is a job submission "
            "to AI Hub's device farm, it does not run locally):\n\n"
            "    pip install qai-hub qai-hub-models\n"
            "    qai-hub configure --api_token <your token>\n\n"
            "See scripts/setup_qai_hub_auth.md.",
            file=sys.stderr,
        )
        return 1

    cmd = [sys.executable, "-m", "qai_hub_models.models.yolov11_det.export",
           "--quantize", args.quantize]
    if args.target_runtime:
        cmd += ["--target-runtime", args.target_runtime]
    print(f"$ {' '.join(cmd)}")
    proc = subprocess.run(cmd, check=False)
    if proc.returncode != 0:
        print(
            f"\nExport exited {proc.returncode}. Common real causes: no AI Hub "
            "token configured, a network policy blocking aihub.qualcomm.com "
            "from this machine, or -- per §4's Compute-support caveat -- this "
            "model genuinely not being profilable on the current chipset "
            "target; qai_hub_models' own error message says which.",
            file=sys.stderr,
        )
        return proc.returncode
    print(
        "\nExport finished. Look at the command's own output above for "
        "exactly where it wrote the .onnx (this script does not guess that "
        "path), then run:\n\n"
        f"    python {Path(__file__).name} --stage-from <that directory>\n"
    )
    return 0


def do_stage(args: argparse.Namespace) -> int:
    src = Path(args.stage_from).expanduser().resolve()
    if not src.is_dir():
        print(f"--stage-from {src} is not a directory", file=sys.stderr)
        return 1

    onnx_files = sorted(src.rglob("*.onnx"))
    if not onnx_files:
        print(f"No .onnx file found under {src}. Nothing staged.", file=sys.stderr)
        return 1
    if len(onnx_files) > 1:
        print(
            f"Multiple .onnx files found under {src}; staging the first "
            f"({onnx_files[0].relative_to(src)}). Re-run with a narrower "
            "--stage-from if that's the wrong one:",
            file=sys.stderr,
        )
        for f in onnx_files:
            print(f"    {f.relative_to(src)}", file=sys.stderr)

    dest_dir = BACKEND_ROOT / "data" / "models" / args.model_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "model.onnx"
    shutil.copy2(onnx_files[0], dest)
    print(f"  copied {onnx_files[0].relative_to(src)} -> {dest.relative_to(BACKEND_ROOT)}")

    labels = sorted(src.rglob("labels.json"))
    if labels:
        dest_labels = dest_dir / "labels.json"
        shutil.copy2(labels[0], dest_labels)
        print(f"  copied {labels[0].relative_to(src)} -> {dest_labels.relative_to(BACKEND_ROOT)}")
    else:
        print("  no labels.json found -- YoloOnnxDetector will use its built-in COCO-80 names")

    print(
        f"\nStaged to {dest_dir}. This loads on any machine running the "
        "backend with `onnxruntime` installed -- `onnxruntime-qnn` "
        "specifically if you want it to try Snapdragon NPU acceleration, "
        "still gated on that build genuinely exposing QNNExecutionProvider "
        "(app/models/runtime.py checks, never assumes). Reload the backend:\n\n"
        "    curl -X POST http://127.0.0.1:8756/api/models/reload\n"
        "    curl http://127.0.0.1:8756/api/models/status\n"
    )
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model-id", default=DEFAULT_MODEL_ID,
                   help=f"Local data/models/<id>/ folder name to stage into (default: {DEFAULT_MODEL_ID})")
    p.add_argument("--quantize", default="w8a8_mixed_int16",
                   choices=["w8a8_mixed_int16", "w8a16", "w8a8"],
                   help="Quantization scheme (default: w8a8_mixed_int16)")
    p.add_argument("--target-runtime", default=None,
                   help="Pass through to --target-runtime if your qai_hub_models version "
                        "supports pinning it (e.g. to force ONNX over TFLite/QNN)")
    p.add_argument("--stage-from", default=None,
                   help="Skip the export step and copy a .onnx already exported at this "
                        "path into backend/data/models/<model-id>/")
    args = p.parse_args()

    if args.stage_from:
        return do_stage(args)
    return do_export(args)


if __name__ == "__main__":
    raise SystemExit(main())
