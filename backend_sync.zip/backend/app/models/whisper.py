"""Speech-to-text adapter — Whisper-Base (§17).

§17: "Do not require cloud speech services for the core path."  There is no
network fallback here by design; if no local Whisper asset is present the
adapter says so and the front-end keeps its own on-device recogniser or text
entry.  It never posts audio anywhere (§24).
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, Optional

from app.config import settings
from app.errors import ModelUnavailable
from app.models.base import READY, ModelHealth, SpeechToTextProvider
from app.models.runtime import find_asset, load_onnx_session, model_dir

FALLBACK = "front-end speech recognition or typed input"


class WhisperOnnxProvider(SpeechToTextProvider):
    """Encoder/decoder ONNX pair as exported by the AI Hub whisper_base recipe."""

    def __init__(self, model_id: Optional[str] = None) -> None:
        super().__init__(model_id or settings.stt_model_id, "whisper-onnx")
        self._encoder = None
        self._decoder = None

    def _load(self) -> None:
        root = model_dir(self.model_id)
        enc = find_asset(self.model_id, "encoder.onnx", "whisper_encoder.onnx")
        dec = (root / "decoder.onnx") if (root / "decoder.onnx").exists() else None
        if enc is None or dec is None:
            raise ModelUnavailable(
                f"whisper encoder/decoder pair not found under data/models/{self.model_id}/",
                model=self.model_id, fallback=FALLBACK,
            )
        self._encoder = load_onnx_session(enc)
        self._decoder = load_onnx_session(dec)
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="onnxruntime", accelerator=self._encoder.accelerator,
            npu=self._encoder.npu and self._decoder.npu,
            asset_path=self._encoder.path,
            load_ms=round(self._encoder.load_ms + self._decoder.load_ms, 2),
            detail={"encoder_providers": self._encoder.providers,
                    "decoder_providers": self._decoder.providers},
        )

    async def transcribe(self, audio: bytes, mime_type: str = "audio/wav") -> Dict[str, Any]:
        self.require_ready(fallback=FALLBACK)
        raise ModelUnavailable(
            "Whisper sessions load but the mel front-end and decode loop are bound "
            "to the exported asset's I/O signature on device",
            model=self.model_id, fallback=FALLBACK,
        )


class PocketSphinxProvider(SpeechToTextProvider):
    """CMU PocketSphinx via the modern (5.x) self-contained PyPI wheel (QA fix 6).

    Real, CPU-only, non-synthetic transcription. The 5.x wheel bundles its
    own default acoustic/language model inside the package, so -- unlike
    Whisper, which needs a multi-hundred-MB model pulled from a host this
    sandbox's network policy blocks (openaipublic.azureedge.net /
    huggingface.co, both refused -- see MODEL_STATUS.md) -- this works with
    no network access at all. The honest trade-off: PocketSphinx's generic
    1990s-architecture acoustic model and default language model are far
    less accurate than Whisper, which is exactly why Whisper stays the
    preferred candidate and this is the fallback that's actually reachable
    here, not a substitute claimed to be equivalent.
    """

    def __init__(self, model_id: str = "pocketsphinx_en_us") -> None:
        super().__init__(model_id, "pocketsphinx")
        self._decoder_cls = None
        self._config_kwargs: Dict[str, str] = {}

    def _load(self) -> None:
        try:
            from pocketsphinx import Config, Decoder, get_model_path  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"pocketsphinx not importable ({type(exc).__name__}); "
                "pip install 'pocketsphinx>=5'",
                model=self.model_id, fallback=FALLBACK,
            )
        model_path = Path(get_model_path())
        hmm, lm, dic = (model_path / "en-us" / "en-us", model_path / "en-us" / "en-us.lm.bin",
                        model_path / "en-us" / "cmudict-en-us.dict")
        if not (hmm.exists() and lm.exists() and dic.exists()):
            raise ModelUnavailable(
                f"pocketsphinx default en-us model files missing under {model_path}",
                model=self.model_id, fallback=FALLBACK,
            )
        # Build one decoder now to prove the model actually loads; a fresh
        # Decoder is created per call in transcribe() since a Decoder is not
        # safe to reuse across concurrent utterances.
        config = Config()
        config.set_string("-hmm", str(hmm))
        config.set_string("-lm", str(lm))
        config.set_string("-dict", str(dic))
        config.set_string("-logfn", "/dev/null")
        Decoder(config)  # raises if the model data itself is bad
        self._Decoder, self._Config = Decoder, Config
        self._paths = {"hmm": str(hmm), "lm": str(lm), "dict": str(dic)}
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="pocketsphinx", accelerator="cpu", npu=False,
            asset_path=str(model_path),
            detail={"note": "Real local inference, bundled default en-us model. "
                            "Accuracy is well below Whisper's -- use Whisper when "
                            "a real exported asset is available.",
                    "expects": "16kHz mono 16-bit PCM"},
        )

    async def transcribe(self, audio: bytes, mime_type: str = "audio/wav") -> Dict[str, Any]:
        self.require_ready(fallback=FALLBACK)

        def _run() -> Dict[str, Any]:
            import io
            import wave

            pcm = audio
            try:
                with wave.open(io.BytesIO(audio), "rb") as w:
                    frames = w.readframes(w.getnframes())
                    rate, channels, width = w.getframerate(), w.getnchannels(), w.getsampwidth()
                    if channels != 1 or width != 2 or rate != 16000:
                        import audioop

                        if channels == 2:
                            frames = audioop.tomono(frames, width, 0.5, 0.5)
                        if width != 2:
                            frames = audioop.lin2lin(frames, width, 2)
                        if rate != 16000:
                            frames, _ = audioop.ratecv(frames, 2, 1, rate, 16000, None)
                    pcm = frames
            except wave.Error:
                pass  # already raw PCM, or not a WAV container we can parse

            config = self._Config()
            for k, path in self._paths.items():
                config.set_string(f"-{k}", path)
            config.set_string("-logfn", "/dev/null")
            decoder = self._Decoder(config)
            decoder.start_utt()
            decoder.process_raw(pcm, False, True)
            decoder.end_utt()
            hyp = decoder.hyp()
            text = (hyp.hypstr if hyp else "") or ""
            return {"text": text.strip(), "segments": [], "language": "en",
                    "model": self.model_id}

        return await asyncio.to_thread(_run)


class FasterWhisperProvider(SpeechToTextProvider):
    """Optional CPU path via the ``faster_whisper`` package, if installed."""

    def __init__(self, model_id: str = "whisper_base", size: str = "base") -> None:
        super().__init__(model_id, "faster-whisper")
        self.size = size
        self._model = None

    def _load(self) -> None:
        try:
            from faster_whisper import WhisperModel  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"faster_whisper not importable ({type(exc).__name__})",
                model=self.model_id, fallback=FALLBACK,
            )
        self._model = WhisperModel(self.size, device="cpu", compute_type="int8")
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="faster-whisper", accelerator="cpu", npu=False,
            detail={"size": self.size, "note": "CPU int8 path, no NPU involvement."},
        )

    async def transcribe(self, audio: bytes, mime_type: str = "audio/wav") -> Dict[str, Any]:
        self.require_ready(fallback=FALLBACK)
        tmp = settings.audio_dir / f"stt_{abs(hash(audio)) % (10 ** 12)}.bin"

        def _run() -> Dict[str, Any]:
            tmp.write_bytes(audio)
            try:
                segments, info = self._model.transcribe(str(tmp), beam_size=1)  # type: ignore
                parts = [{"start": round(s.start, 2), "end": round(s.end, 2),
                          "text": s.text.strip()} for s in segments]
                return {
                    "text": " ".join(p["text"] for p in parts).strip(),
                    "segments": parts,
                    "language": getattr(info, "language", None),
                    "model": self.model_id,
                }
            finally:
                try:
                    tmp.unlink()
                except OSError:
                    pass

        return await asyncio.to_thread(_run)
