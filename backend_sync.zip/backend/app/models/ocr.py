"""OCR adapters — EasyOCR / TrOCR (§3), producing the §9 record shape.

    {"text": "E17", "confidence": 0.97, "bbox": [120, 80, 220, 130],
     "source": "live_frame"}

When no OCR backend is installed the pipeline degrades to letting the VLM read
text visually (§25), and the adapter says so rather than returning nothing.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

from app.config import settings
from app.errors import ModelUnavailable
from app.logging_setup import get_logger
from app.models.base import READY, ImageRef, ModelHealth, OCRProvider
from app.models.runtime import find_asset, load_onnx_session

log = get_logger(__name__)

FALLBACK = "vlm visual text reading"


class EasyOCRProvider(OCRProvider):
    """Wraps the ``easyocr`` package when it is installed locally."""

    def __init__(self, model_id: Optional[str] = None, languages: Optional[List[str]] = None):
        super().__init__(model_id or settings.ocr_model_id, "easyocr")
        self.languages = languages or ["en"]
        self._reader = None

    def _load(self) -> None:
        try:
            import easyocr  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"easyocr not importable ({type(exc).__name__})",
                model=self.model_id, fallback=FALLBACK,
            )
        self._reader = easyocr.Reader(self.languages, gpu=False, verbose=False)
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="easyocr", accelerator="cpu", npu=False,
            detail={"languages": self.languages,
                    "note": "CPU path. Replace with a Workbench-exported asset for NPU."},
        )

    async def extract(self, image: ImageRef) -> List[Dict[str, Any]]:
        self.require_ready(fallback=FALLBACK)

        def _run() -> List[Dict[str, Any]]:
            raw = self._reader.readtext(image.path)  # type: ignore[union-attr]
            out: List[Dict[str, Any]] = []
            for box, text, conf in raw:
                xs = [float(p[0]) for p in box]
                ys = [float(p[1]) for p in box]
                out.append({
                    "text": str(text).strip(),
                    "confidence": round(float(conf), 4),
                    "bbox": [round(min(xs), 1), round(min(ys), 1),
                             round(max(xs), 1), round(max(ys), 1)],
                    "source": image.source,
                    "model": self.model_id,
                })
            return [r for r in out if r["text"]]

        return await asyncio.to_thread(_run)


class TesseractOCRProvider(OCRProvider):
    """Wraps the system ``tesseract`` binary via ``pytesseract`` (QA fix 6).

    Real, CPU-only, non-synthetic OCR: this is not a heuristic stand-in and
    not a claim of NPU/Snapdragon acceleration -- accelerator is reported as
    "cpu" and npu=False because that is what it genuinely runs on here.
    Unlike EasyOCR/TrOCR (which need a model download this sandbox's network
    policy blocks -- see MODEL_STATUS.md), tesseract's language data ships
    with the OS package, so this path works with no network access at all,
    which is also exactly why it is tried first.
    """

    def __init__(self, model_id: Optional[str] = None, languages: Optional[List[str]] = None):
        super().__init__(model_id or "tesseract_eng", "tesseract")
        self.languages = languages or ["eng"]
        self._pytesseract = None

    def _load(self) -> None:
        import shutil as _shutil

        binary = _shutil.which("tesseract")
        if binary is None:
            raise ModelUnavailable(
                "tesseract binary not on PATH (apt-get install tesseract-ocr)",
                model=self.model_id, fallback=FALLBACK,
            )
        try:
            import pytesseract  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"pytesseract not importable ({type(exc).__name__}); pip install pytesseract",
                model=self.model_id, fallback=FALLBACK,
            )
        pytesseract.pytesseract.tesseract_cmd = binary
        try:
            version = str(pytesseract.get_tesseract_version())
        except Exception as exc:
            raise ModelUnavailable(
                f"tesseract binary did not respond ({type(exc).__name__})",
                model=self.model_id, fallback=FALLBACK,
            )
        self._pytesseract = pytesseract
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="tesseract", accelerator="cpu", npu=False,
            asset_path=binary,
            detail={"languages": self.languages, "tesseract_version": version,
                    "note": "Real local inference (system tesseract), CPU only. "
                            "Not a Qualcomm/QNN export -- no NPU claim is made."},
        )

    async def extract(self, image: ImageRef) -> List[Dict[str, Any]]:
        self.require_ready(fallback=FALLBACK)
        pt = self._pytesseract

        def _run() -> List[Dict[str, Any]]:
            data = pt.image_to_data(image.path, lang="+".join(self.languages),
                                    output_type=pt.Output.DICT)
            out: List[Dict[str, Any]] = []
            n = len(data.get("text") or [])
            for i in range(n):
                text = (data["text"][i] or "").strip()
                if not text:
                    continue
                conf_raw = data["conf"][i]
                try:
                    conf = max(0.0, float(conf_raw)) / 100.0
                except (TypeError, ValueError):
                    conf = 0.0
                x, y = float(data["left"][i]), float(data["top"][i])
                w, h = float(data["width"][i]), float(data["height"][i])
                out.append({
                    "text": text,
                    "confidence": round(conf, 4),
                    "bbox": [round(x, 1), round(y, 1), round(x + w, 1), round(y + h, 1)],
                    "source": image.source,
                    "model": self.model_id,
                })
            return out

        return await asyncio.to_thread(_run)


class TrOCROnnxProvider(OCRProvider):
    """ONNX TrOCR path for an exported Workbench asset."""

    def __init__(self, model_id: str = "trocr") -> None:
        super().__init__(model_id, "trocr-onnx")
        self._sess = None

    def _load(self) -> None:
        asset = find_asset(self.model_id, "model.onnx")
        if asset is None:
            raise ModelUnavailable(
                f"no ONNX asset under data/models/{self.model_id}/",
                model=self.model_id, fallback=FALLBACK,
            )
        loaded = load_onnx_session(asset)
        self._sess = loaded
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="onnxruntime", accelerator=loaded.accelerator, npu=loaded.npu,
            asset_path=loaded.path, load_ms=loaded.load_ms,
            detail={"execution_providers": loaded.providers,
                    "note": "Recogniser only; pair with a text detector for bboxes."},
        )

    async def extract(self, image: ImageRef) -> List[Dict[str, Any]]:
        self.require_ready(fallback=FALLBACK)
        raise ModelUnavailable(
            "TrOCR recognition head is wired but the detection stage is not exported yet",
            model=self.model_id, fallback=FALLBACK,
        )
