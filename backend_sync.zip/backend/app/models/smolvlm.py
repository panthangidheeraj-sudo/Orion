"""SmolVLM-500M-Instruct — a real, CPU-only multimodal VLM (§3 dev fallback).

Context: Intern3.5-VL-2B (the Snapdragon-target VLM named in the spec) needs a
Qualcomm AI Hub account/API token plus physical or cloud-hosted Snapdragon
hardware to export — neither is available in this environment, and nothing
here fakes that path.  This adapter is the honestly-labelled alternative: a
real, small, genuinely-multimodal model (idefics3 architecture, Apache-2.0),
running its own hand-rolled ONNX Runtime inference loop entirely on CPU.

Two rules this file exists to honour (§4, base.py's module docstring):

1.  It NEVER requests or reports an NPU/QNN execution provider.  This asset
    was exported for CPU inference and was never profiled on Snapdragon
    hardware, so claiming otherwise would be exactly the fabrication the
    spec forbids.  ``accelerator`` is hard-set to ``"cpu"``.
2.  If the three ONNX graphs or the tokenizer are missing, this adapter
    reports ``unavailable`` and lets the registry fall through to
    ``heuristic-offline`` (or whatever candidate is next).  It never
    half-loads and returns plausible-looking text from a broken pipeline.

Known, documented simplification (not a hidden shortcut): the real
Idefics3ImageProcessor tiles a large image into multiple 512x512 crops plus a
downscaled global thumbnail ("image splitting") for extra visual detail. That
tiling logic is substantial and this adapter does not reproduce it. Instead
every image is treated as a single global 512x512 patch (resized to fit,
padded, with a real ``pixel_attention_mask`` marking the padding). The vision
encoder, embedding table and decoder are the real exported weights running
real inference on the real photograph -- only the multi-crop detail boost is
skipped. ``capabilities()`` and ``ModelHealth.detail`` both say so.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Sequence

import numpy as np

from app.config import settings
from app.errors import ModelUnavailable
from app.logging_setup import get_logger
from app.models.base import READY, ImageRef, ModelHealth, ReasoningProvider
from app.models.qwen_vl import parse_tool_calls
from app.models.runtime import model_dir
from app.util import ms

log = get_logger(__name__)

FALLBACK = "heuristic-offline reasoner"

_PATCH_SIZE = 512
_TOKENS_PER_PATCH = 64  # (512/16)^2 / scale_factor^2 = 1024 / 16


class SmolVLMOnnxProvider(ReasoningProvider):
    """Hand-rolled 3-graph ONNX Runtime pipeline for SmolVLM-500M-Instruct.

    vision_encoder -> embed_tokens -> decoder_model_merged (with KV cache),
    exactly the three exported graphs HuggingFaceTB ships, run with
    ``onnxruntime``'s plain ``CPUExecutionProvider``. No onnxruntime-genai,
    no torch, no transformers -- just onnxruntime + the standalone
    ``tokenizers`` package (Rust BPE, no ML framework attached).
    """

    def __init__(self, model_id: Optional[str] = None, max_new_tokens: int = 220) -> None:
        super().__init__(model_id or settings.smolvlm_model_id, "onnx-cpu-smolvlm")
        self.max_new_tokens = max_new_tokens
        self._tok = None
        self._vision_sess = None
        self._embed_sess = None
        self._decoder_sess = None
        self._cfg: Dict[str, Any] = {}
        self._image_token_id: int = 49190
        self._eos_token_id: int = 49279
        self._num_layers: int = 32
        self._num_kv_heads: int = 5
        self._head_dim: int = 64

    # ------------------------------------------------------------------ load
    def _load(self) -> None:
        root = model_dir(self.model_id)
        required_text = ["config.json", "tokenizer.json", "tokenizer_config.json",
                          "generation_config.json"]
        missing = [n for n in required_text if not (root / n).exists()]
        onnx_dir = root / "onnx"
        graphs = {
            "vision_encoder": sorted(onnx_dir.glob("*vision_encoder*.onnx")) if onnx_dir.exists() else [],
            "embed_tokens": sorted(onnx_dir.glob("*embed_tokens*.onnx")) if onnx_dir.exists() else [],
            "decoder_model_merged": sorted(onnx_dir.glob("*decoder_model_merged*.onnx")) if onnx_dir.exists() else [],
        }
        missing_graphs = [k for k, v in graphs.items() if not v]
        if missing or missing_graphs:
            raise ModelUnavailable(
                f"SmolVLM asset incomplete under data/models/{self.model_id}/ "
                f"(missing files: {missing or 'none'}, missing onnx graphs: {missing_graphs or 'none'})",
                model=self.model_id, fallback=FALLBACK,
            )
        try:
            import onnxruntime as ort  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"onnxruntime not importable ({type(exc).__name__})",
                model=self.model_id, fallback=FALLBACK,
            )
        try:
            from tokenizers import Tokenizer  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"'tokenizers' package not importable ({type(exc).__name__}); "
                "install it with 'pip install tokenizers' (no torch required)",
                model=self.model_id, fallback=FALLBACK,
            )

        self._cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
        gen_cfg = json.loads((root / "generation_config.json").read_text(encoding="utf-8"))
        self._image_token_id = int(self._cfg.get("image_token_id", 49190))
        self._eos_token_id = int(gen_cfg.get("eos_token_id", 49279))
        text_cfg = self._cfg.get("text_config", {})
        self._num_layers = int(text_cfg.get("num_hidden_layers", 32))
        self._num_kv_heads = int(text_cfg.get("num_key_value_heads", 5))
        hidden = int(text_cfg.get("hidden_size", 960))
        heads = int(text_cfg.get("num_attention_heads", 15))
        self._head_dim = hidden // heads

        t0 = ms()
        # CPU only, deliberately -- see module docstring. This asset was never
        # exported for or profiled on QNN, so it must never request it.
        so = ort.SessionOptions()
        so.log_severity_level = 3
        try:
            self._vision_sess = ort.InferenceSession(
                str(graphs["vision_encoder"][0]), sess_options=so, providers=["CPUExecutionProvider"])
            self._embed_sess = ort.InferenceSession(
                str(graphs["embed_tokens"][0]), sess_options=so, providers=["CPUExecutionProvider"])
            self._decoder_sess = ort.InferenceSession(
                str(graphs["decoder_model_merged"][0]), sess_options=so, providers=["CPUExecutionProvider"])
        except Exception as exc:
            raise ModelUnavailable(
                f"failed to build onnxruntime session(s): {type(exc).__name__}: {exc}",
                model=self.model_id, fallback=FALLBACK,
            )
        self._tok = Tokenizer.from_file(str(root / "tokenizer.json"))
        load_ms = round(ms() - t0, 2)

        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="onnxruntime", accelerator="cpu", npu=False, synthetic=False,
            asset_path=str(root), load_ms=load_ms,
            detail={
                "mode": "cpu_development",
                "note": ("Runs the real exported SmolVLM-500M-Instruct ONNX graphs on "
                          "CPUExecutionProvider. This is a development-mode CPU path, not "
                          "Snapdragon/NPU execution -- this asset has never been exported "
                          "for or profiled on QNN."),
                "graphs": {k: v[0].name for k, v in graphs.items()},
                "image_preprocessing": "single global 512x512 patch, no multi-crop splitting",
                "max_new_tokens": self.max_new_tokens,
                "greedy_decoding": True,
            },
        )

    def capabilities(self) -> Dict[str, Any]:
        return {**super().capabilities(), "streaming": True, "images": True,
                "tool_calls": "prompted", "accelerator": "cpu",
                "image_splitting": False}

    # ------------------------------------------------------------- prompting
    def _format_prompt(self, messages: Sequence[Dict[str, Any]], num_images: int) -> str:
        """Reproduce SmolVLM's chat_template.json by hand (no Jinja needed).

        Template (verbatim, from chat_template.json):
            <|im_start|>{% for message in messages %}{{role|capitalize}}
            {':' if first content is image else ': '}{{...content...}}
            <end_of_utterance>\\n{% endfor %}{% if add_generation_prompt %}Assistant:{% endif %}

        Every non-final message here is plain text (system/earlier turns);
        the final user turn gets ``num_images`` literal ``<image>``
        placeholders prepended, one per attached photo, exactly as the real
        Idefics3 processor lays them out before it expands each one below.
        """
        parts = ["<|im_start|>"]
        last_idx = len(messages) - 1
        for idx, m in enumerate(messages):
            role = str(m.get("role", "user"))
            label = role[:1].upper() + role[1:].lower()
            text = str(m.get("content", ""))
            if idx == last_idx and num_images:
                sep = ":"
                body = "<image>" * num_images + " " + text
            else:
                sep = ": "
                body = text
            parts.append(f"{label}{sep}{body}<end_of_utterance>\n")
        parts.append("Assistant:")
        prompt = "".join(parts)

        # Expand each literal <image> placeholder into its real token block.
        # Real HF Idefics3Processor does this same post-templating expansion;
        # with splitting disabled a plain global patch expands to
        # <fake_token_around_image><image>*64<fake_token_around_image>.
        block = "<fake_token_around_image>" + "<image>" * _TOKENS_PER_PATCH + "<fake_token_around_image>"
        return prompt.replace("<image>", block)

    # --------------------------------------------------------------- vision
    def _preprocess_image(self, ref: ImageRef) -> tuple:
        from PIL import Image

        img = Image.open(ref.path).convert("RGB")
        w, h = img.size
        scale = min(_PATCH_SIZE / w, _PATCH_SIZE / h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        img = img.resize((nw, nh), Image.BILINEAR)

        canvas = np.zeros((_PATCH_SIZE, _PATCH_SIZE, 3), dtype=np.float32)
        mask = np.zeros((_PATCH_SIZE, _PATCH_SIZE), dtype=bool)
        arr = np.asarray(img, dtype=np.float32) / 255.0
        canvas[:nh, :nw, :] = arr
        mask[:nh, :nw] = True

        # Idefics3ImageProcessor: rescale (1/255, done above) then normalize
        # with mean=std=0.5 -> equivalent to x*2-1 on the already-rescaled data.
        normed = (canvas - 0.5) / 0.5
        chw = np.transpose(normed, (2, 0, 1))  # HWC -> CHW
        return chw.astype(np.float32), mask

    def _vision_features(self, images: Sequence[ImageRef]) -> np.ndarray:
        chw_list, mask_list = [], []
        for ref in images:
            chw, mask = self._preprocess_image(ref)
            chw_list.append(chw)
            mask_list.append(mask)
        pixel_values = np.stack(chw_list, axis=0)[np.newaxis, ...]  # [1, N, 3, 512, 512]
        pixel_attention_mask = np.stack(mask_list, axis=0)[np.newaxis, ...]  # [1, N, 512, 512]
        out = self._vision_sess.run(
            None, {"pixel_values": pixel_values, "pixel_attention_mask": pixel_attention_mask})
        (features,) = out  # [num_patches, 64, 960]
        return features.reshape(-1, features.shape[-1])  # [N*64, 960]

    # -------------------------------------------------------------- decode
    def _empty_past(self, batch: int = 1):
        shape = (batch, self._num_kv_heads, 0, self._head_dim)
        feed = {}
        for i in range(self._num_layers):
            feed[f"past_key_values.{i}.key"] = np.zeros(shape, dtype=np.float32)
            feed[f"past_key_values.{i}.value"] = np.zeros(shape, dtype=np.float32)
        return feed

    def _run_generate(self, prompt_ids: List[int], image_features: Optional[np.ndarray]) -> List[int]:
        input_ids = np.array([prompt_ids], dtype=np.int64)
        (embeds,) = self._embed_sess.run(None, {"input_ids": input_ids})  # [1, T, 960]

        if image_features is not None:
            positions = [i for i, t in enumerate(prompt_ids) if t == self._image_token_id]
            if len(positions) != image_features.shape[0]:
                log.warning(
                    "smolvlm: %d <image> slots but %d vision features; truncating to the shorter",
                    len(positions), image_features.shape[0])
            n = min(len(positions), image_features.shape[0])
            for j in range(n):
                embeds[0, positions[j], :] = image_features[j]

        past = self._empty_past()
        seq_len = embeds.shape[1]
        attention_mask = np.ones((1, seq_len), dtype=np.int64)
        position_ids = np.arange(seq_len, dtype=np.int64)[np.newaxis, :]

        generated: List[int] = []
        total_len = seq_len
        cur_embeds = embeds
        repeat_run = 0
        prev_id: Optional[int] = None
        for _ in range(self.max_new_tokens):
            feed = {
                "inputs_embeds": cur_embeds,
                "attention_mask": attention_mask,
                "position_ids": position_ids,
                **past,
            }
            outputs = self._decoder_sess.run(None, feed)
            logits = outputs[0]
            next_id = int(np.argmax(logits[0, -1, :]))
            generated.append(next_id)
            if next_id == self._eos_token_id:
                break
            # Known small-model failure mode under greedy decoding: locking
            # onto one token (typically a digit) and repeating it to the
            # ceiling instead of ever emitting EOS. Stop early rather than
            # burn the whole budget on a degenerate loop -- this shortens a
            # bad answer, it does not paper over the underlying limitation
            # (see MODEL_STATUS.md).
            repeat_run = repeat_run + 1 if next_id == prev_id else 0
            prev_id = next_id
            if repeat_run >= 5:
                break

            present = outputs[1:]
            past = {}
            for i in range(self._num_layers):
                past[f"past_key_values.{i}.key"] = present[2 * i]
                past[f"past_key_values.{i}.value"] = present[2 * i + 1]

            total_len += 1
            (cur_embeds,) = self._embed_sess.run(None, {"input_ids": np.array([[next_id]], dtype=np.int64)})
            attention_mask = np.ones((1, total_len), dtype=np.int64)
            position_ids = np.array([[total_len - 1]], dtype=np.int64)

        # Trim a trailing degenerate run down to a single occurrence so the
        # decoded text reads as "...7." rather than "...7.0000000000".
        while len(generated) >= 2 and generated[-1] == generated[-2]:
            generated.pop()
        return generated

    # ---------------------------------------------------------------- API
    async def generate(self, messages, images=None, tools=None, context=None) -> Dict[str, Any]:
        self.require_ready(fallback=FALLBACK)
        loop = asyncio.get_running_loop()

        def _work() -> str:
            imgs = list(images or [])[:4]
            image_features = self._vision_features(imgs) if imgs else None
            msgs = list(messages)
            if tools:
                tool_desc = json.dumps([t for t in tools], ensure_ascii=False)[:2000]
                msgs = [{"role": "system",
                        "content": ("Tools available (call at most one, as a fenced "
                                    "```tool_call{...}``` JSON block with keys tool/arguments "
                                    f"if needed): {tool_desc}")}] + msgs
            prompt = self._format_prompt(msgs, num_images=len(imgs))
            prompt_ids = self._tok.encode(prompt, add_special_tokens=False).ids
            gen_ids = self._run_generate(prompt_ids, image_features)
            text = self._tok.decode(gen_ids, skip_special_tokens=True)
            return text

        text = await loop.run_in_executor(None, _work)
        clean, calls = parse_tool_calls(text)
        return {"text": clean, "tool_calls": calls, "model": self.model_id,
                "usage": {"output_chars": len(text)}}

    def supports_streaming(self) -> bool:
        return True

    async def stream(self, messages, images=None, tools=None, context=None) -> AsyncIterator[Dict[str, Any]]:
        # Greedy decode is cheap to reproduce as a single generate() call and
        # then replay token-by-token; a genuinely incremental stream would
        # need the same loop restructured to yield mid-decode, which is not
        # worth the complexity for a 500M CPU dev-mode model. Callers that
        # need low-latency partial output should prefer generate().
        result = await self.generate(messages, images=images, tools=tools, context=context)
        yield {"type": "text", "value": result.get("text", "")}
        yield {"type": "done", "value": result}
