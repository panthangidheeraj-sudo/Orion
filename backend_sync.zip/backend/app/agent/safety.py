"""Safety layer (§19).

Two places, as the specification asks: a policy the agent is told about in its
prompt, and a validator that inspects the finished response before it leaves
the backend.  The validator is the one that matters, because it applies to any
reasoning provider — including one swapped in later that has never seen our
prompt.

It does four things:

* attaches the right hazard notice when the response touches a hazardous
  procedure;
* flags language that would have the technician work on live equipment, and
  rewrites the response to lead with isolation;
* flags fabricated measurements — a numeric reading asserted as fact that no
  tool and no technician statement ever produced;
* answers a hazardous action the *technician* proposes — "can I touch this?",
  "can I loosen this while it's pressurised?" — directly and before anything
  else, whether or not the diagnostic composer below it recognised the
  symptom (QA report §11: this used to depend entirely on the symptom table
  matching, so "can I touch this sparking wire?" got no warning at all
  because nothing about it matched one of the seven symptom patterns).

That fourth job is deliberately independent of symptom classification and of
the composed answer: it reads the technician's own question, not the model's
output, so it fires even when the reasoner has nothing to say.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence

from app.logging_setup import get_logger

log = get_logger(__name__)

HAZARDS = [
    {
        "key": "electrical",
        "pattern": re.compile(
            r"\b(terminal|winding|busbar|contactor|live(?!\s+mode)|energi[sz]ed|voltage|mains|"
            r"phase|earth|ground fault|insulation resistance|megger|capacitor|"
            r"drive|inverter|vfd|panel|switchgear)\b", re.I),
        "notice": "Electrical hazard. Isolate the supply, apply lock-out/tag-out and prove dead "
                  "with a tester you have proven on a known source before touching any "
                  "conductor. Stored energy in drive capacitors can persist after isolation — "
                  "observe the manufacturer's discharge time.",
    },
    {
        "key": "rotating",
        "pattern": re.compile(
            r"\b(shaft|coupling|belt|pulley|fan|impeller|rotor|gearbox|spindle|"
            r"rotating|chain|sprocket)\b", re.I),
        "notice": "Rotating machinery. Isolate and confirm the shaft has come to rest before "
                  "removing a guard or reaching into the machine. Do not rely on the control "
                  "stop alone.",
    },
    {
        "key": "thermal",
        "pattern": re.compile(r"\b(hot|overheat|thermal|burn|scorch|steam|temperature above|"
                              r"\d{2,3}\s*°?\s?[cf]\b)", re.I),
        "notice": "Hot surfaces. Allow the machine to cool or use appropriate protection before "
                  "contact; take temperatures with a non-contact instrument where possible.",
    },
    {
        "key": "pressure",
        "pattern": re.compile(r"\b(hydraulic|pneumatic|pressure|accumulator|bar\b|psi\b|"
                              r"compressed air)\b", re.I),
        "notice": "Stored pressure. Depressurise the circuit and confirm zero pressure at the "
                  "gauge before breaking any joint. Hydraulic injection injuries are serious "
                  "even when the skin looks unbroken.",
    },
    {
        "key": "chemical",
        "pattern": re.compile(r"\b(coolant|solvent|electrolyte|acid|refrigerant|"
                              r"lubricant spill|fume)\b", re.I),
        "notice": "Chemical exposure. Check the substance's safety data sheet for handling, "
                  "ventilation and personal protective equipment before proceeding.",
    },
]

# Language that would put hands on live or moving equipment.
UNSAFE_INSTRUCTION = re.compile(
    r"\b(while (?:it(?:'s| is) )?(?:still )?(?:running|energi[sz]ed|live|powered)|"
    r"without isolating|no need to isolate|don'?t bother isolating|"
    r"touch the (?:live|energi[sz]ed) |bypass the (?:interlock|guard|e-?stop)|"
    r"remove the guard while|defeat the interlock)\b", re.I)
# Note: this pattern's "live" mentions are all preceded by a verb phrase
# ("while ... live", "touch the live ...") that "Live Mode" never satisfies,
# so it doesn't need the same guard as the bare `\blive\b` cues below.

MEASUREMENT = re.compile(
    r"(?<![\w.])(\d{1,5}(?:\.\d+)?)\s?(°\s?[CF]|degrees?\s?[CF]?|V(?:AC|DC)?|A\b|mA\b|"
    r"k?Ω|ohms?\b|Hz\b|rpm\b|bar\b|psi\b|kW\b|mm/s\b|dB\b)", re.I)

PROFESSIONAL_NOTE = (
    "This is general troubleshooting guidance, not an authorised procedure for this "
    "specific machine. Follow the manufacturer's manual and your site's permit and "
    "competency requirements; some work is restricted to authorised persons."
)


def detect_hazards(text: str) -> List[Dict[str, str]]:
    found = []
    for h in HAZARDS:
        if h["pattern"].search(text or ""):
            found.append({"key": h["key"], "notice": h["notice"]})
    return found


# --------------------------------------------------------- hazardous action

# Six categories, independent of `heuristic.SYMPTOMS` (§ QA fix 1). Each has a
# `context` pattern (the hazardous condition is present) and an `action`
# pattern (the technician describes or asks about direct physical contact or
# intervention). `context` alone is enough for a precaution; `context` +
# `action` together — "can I touch this live wire?" — get the strong, direct
# "No, don't" verdict, because that is a yes/no safety question and a
# generic diagnostic paragraph is not an answer to it.
ACTION_HAZARDS: List[Dict[str, Any]] = [
    {
        "key": "energized_contact",
        "label": "Energized / live electrical equipment",
        "context": re.compile(
            # `live` alone is a real electrical-hazard cue ("still live wire"),
            # but also matches the product's own "Live Mode" feature name --
            # exclude that one specific, harmless phrase rather than dropping
            # the bare word entirely (QA fix 7 regression: "what did we see in
            # Live Mode just now?" was mis-flagged as an electrical hazard).
            r"\b(energi[sz]ed|live(?!\s+mode)|spark(?:s|ing)?|exposed (?:wire|conductor|terminal)|"
            r"bus\s*-?bar|open (?:panel|enclosure)|panel (?:door )?(?:is )?open|"
            r"bare (?:wire|conductor)|still (?:live|energi[sz]ed|powered|connected))\b", re.I),
        "action": re.compile(
            r"\b(touch(?:ing)?|grab(?:bing)?|push(?:ing)? it back|tape (?:it|them) (?:up|back)?|"
            r"probe it|reach in|hold it|jumper|bypass|leave it (?:live|connected)|"
            r"work on it (?:live|while)|wire it back)\b", re.I),
        "verdict": ("No — do not touch it. Isolate the circuit, apply lock-out/tag-out, and prove "
                    "it dead with a tester you've proven on a known live source before any contact. "
                    "A sparking or exposed conductor may still be live even if the machine looks off."),
        "precaution": ("Electrical hazard. Isolate the supply, lock out/tag out, and prove dead "
                       "before touching any conductor or terminal."),
    },
    {
        "key": "rotating_contact",
        "label": "Rotating machinery",
        "context": re.compile(
            r"\b(spinning|rotating|shaft (?:is )?(?:spinning|turning|rotating)|"
            r"guard (?:is |was )?(?:off|removed|open)|while it'?s running|"
            r"coupling|belt|pulley)\b", re.I),
        "action": re.compile(
            r"\b(by hand|reach in|touch(?:ing)?|grab(?:bing)?|feel (?:it|for)|hold it|"
            r"put my hand|check.*by hand)\b", re.I),
        "verdict": ("No — do not put your hand near it while it can move. Isolate the machine and "
                    "confirm the shaft has fully come to rest before reaching in or working without "
                    "the guard, even briefly."),
        "precaution": ("Rotating machinery hazard. Isolate and confirm the shaft has stopped before "
                       "removing a guard or reaching into the machine."),
    },
    {
        "key": "hot_surface_contact",
        "label": "Hot surfaces / bearings",
        "context": re.compile(
            r"\b(hot\b|overheat\w*|scald\w*|burn(?:ing|s)?\s+hazard|"
            r"\d{2,3}\s*°?\s?[cf]\b|uncomfortably hot|too hot to)\b", re.I),
        "action": re.compile(
            r"\b(grab(?:bing)?|touch(?:ing)?|feel (?:it|how)|hold it|put my hand|bare[- ]hand)\b",
            re.I),
        "verdict": ("No — don't touch it bare-handed. Use a non-contact thermometer, or let it cool "
                    "and use appropriate protection before any contact. A housing this hot is a "
                    "burn hazard."),
        "precaution": ("Hot-surface hazard. Let the machine cool or use protection before contact; "
                       "take temperatures with a non-contact instrument where possible."),
    },
    {
        "key": "pressurized_contact",
        "label": "Pressurized hydraulic / pneumatic systems",
        "context": re.compile(
            r"\b(pressuri[sz]ed|under pressure|still pressuri[sz]ed|hydraulic (?:line|fitting|hose)|"
            r"pneumatic (?:line|fitting|hose)|accumulator)\b", re.I),
        "action": re.compile(
            r"\b(loosen(?:ing)?|crack(?:ing)? open|open(?:ing)?|undo(?:ing)?|remove|"
            r"break the joint|relieve (?:the )?pressure by)\b", re.I),
        "verdict": ("No — do not loosen or open a fitting while the line is pressurised. Depressurise "
                    "the system fully and confirm zero at the gauge first. Hydraulic fluid injection "
                    "injuries can happen even through skin that looks unbroken."),
        "precaution": ("Stored-pressure hazard. Depressurise and confirm zero at the gauge before "
                       "breaking any joint."),
    },
    {
        "key": "damaged_cable_contact",
        "label": "Damaged or live cables",
        "context": re.compile(
            r"\b(damaged|frayed|split|exposed|cracked|worn) (?:insulation|cable|cord|wire)|"
            r"insulation (?:is )?(?:split|damaged|frayed|cracked)|"
            r"cable.*(?:damaged|frayed|split|exposed|strands? visible)|strands? (?:visible|showing)",
            re.I),
        "action": re.compile(
            r"\b(grab(?:bing)?|pull(?:ing)? it free|touch(?:ing)?|handle|keep it running|"
            r"keep using|continue (?:using|running)|keep operating|leave it (?:connected|running))\b",
            re.I),
        "verdict": ("No — treat damaged insulation as live until proven otherwise. Isolate the supply "
                    "and confirm it's dead before touching the cable, and don't run the machine on it "
                    "until it's replaced or properly repaired."),
        "precaution": ("Damaged-insulation hazard. Isolate and prove dead before handling; do not "
                       "keep running the machine on damaged insulation."),
    },
    {
        "key": "terminal_contact",
        "label": "Touching conductors / terminals",
        "context": re.compile(
            r"\b(terminal (?:block|strip)?|conductor|contact(?:s)?|busbar)\b.*"
            r"(?:discolor|discolour|browned|burnt|hot|loose)|"
            r"(?:discolor|discolour|browned|burnt|loose).*\b(terminal|conductor|contact|busbar)\b",
            re.I),
        "action": re.compile(
            r"\b(touch(?:ing)?|probe|measure|check).*\b(terminal|it|them)\b|"
            r"still energi[sz]ed|panel is still energi[sz]ed", re.I),
        "verdict": ("No — don't probe or touch it while the panel is energised. Isolate the circuit, "
                    "lock out/tag out and prove dead before opening the terminal cover or taking any "
                    "reading inside it."),
        "precaution": ("Electrical hazard at the terminal. Isolate and prove dead before opening the "
                       "cover or taking a reading."),
    },
]


def detect_action_hazards(user_text: str) -> List[Dict[str, Any]]:
    """What the *technician* described wanting to do, not what the model said.

    Returns one entry per matched category with a `direct` flag: True when
    both the hazardous condition and a proposed physical action are present
    (a yes/no safety question that needs a yes/no answer), False when only
    the condition is present (worth a precaution, not necessarily a question).
    """
    text = user_text or ""
    found: List[Dict[str, Any]] = []
    seen = set()
    for h in ACTION_HAZARDS:
        if not h["context"].search(text):
            continue
        if h["key"] in seen:
            continue
        seen.add(h["key"])
        direct = bool(h["action"].search(text))
        found.append({
            "key": h["key"], "label": h["label"], "direct": direct,
            "verdict": h["verdict"], "precaution": h["precaution"],
        })
    return found


def review_intent(user_text: str) -> Optional[Dict[str, Any]]:
    """Build the safety block to lead the response with, or None if nothing fired.

    Ordering rule from the QA fix request: safety guidance goes *before*
    diagnostic guidance, and a direct yes/no question about a hazardous
    action gets an explicit answer, not just a hazard tag.
    """
    hazards = detect_action_hazards(user_text)
    if not hazards:
        return None
    lines: List[str] = []
    keys: List[str] = []
    any_direct = False
    for h in hazards:
        keys.append(h["key"])
        if h["direct"]:
            any_direct = True
            lines.append(h["verdict"])
        else:
            lines.append(h["precaution"])
    title = "Safety — answer this first" if any_direct else "Safety"
    block_text = "\n".join(f"- {ln}" for ln in lines)
    return {
        "title": title,
        "text": block_text,
        "lines": lines,
        "keys": keys,
        "direct": any_direct,
    }


def _known_numbers(evidence: Dict[str, Any], user_text: str) -> set:
    """Every number the pipeline can legitimately state."""
    known = set(re.findall(r"\d{1,5}(?:\.\d+)?", user_text or ""))

    def walk(node: Any, depth: int = 0) -> None:
        if depth > 6:
            return
        if isinstance(node, str):
            known.update(re.findall(r"\d{1,5}(?:\.\d+)?", node))
        elif isinstance(node, (int, float)):
            known.add(str(node))
            known.add(str(int(node)) if float(node).is_integer() else str(node))
        elif isinstance(node, dict):
            for v in node.values():
                walk(v, depth + 1)
        elif isinstance(node, (list, tuple)):
            for v in node:
                walk(v, depth + 1)

    walk(evidence)
    return known


def review(text: str, evidence: Optional[Dict[str, Any]] = None,
           user_text: str = "", sections: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Validate a finished response.  Returns the (possibly amended) response."""
    evidence = evidence or {}
    notes: List[str] = []
    blocked: List[str] = []

    haystack = text or ""
    for s in sections or []:
        haystack += "\n" + "\n".join(str(i) for i in s.get("items", []))

    hazards = detect_hazards(haystack)

    unsafe = UNSAFE_INSTRUCTION.findall(haystack)
    if unsafe:
        blocked.append("instruction to work on live or moving equipment")
        log.warning("safety layer rewrote a response containing unsafe instruction(s)")

    known = _known_numbers(evidence, user_text)
    invented: List[str] = []
    for value, unit in MEASUREMENT.findall(haystack):
        if value not in known:
            invented.append(f"{value} {unit}".strip())
    # Ranges and thresholds quoted from a manual are fine; a bare assertion is not.
    invented = [v for v in dict.fromkeys(invented)][:6]

    amended = text
    if blocked:
        amended = (
            "Before anything else: isolate the machine, apply lock-out/tag-out and prove dead. "
            "Do not work on live or moving equipment.\n\n" + (text or "")
        )
        notes.append("Response was amended to lead with isolation.")
    if invented:
        notes.append(
            "These figures are not backed by a measurement in this session — treat them as "
            "values to confirm, not as readings: " + ", ".join(invented))

    return {
        "text": amended,
        "hazards": hazards,
        "hazard_notices": [h["notice"] for h in hazards],
        "professional_note": PROFESSIONAL_NOTE if hazards else None,
        "unverified_figures": invented,
        "blocked_patterns": blocked,
        "notes": notes,
        "safe": not blocked,
    }
