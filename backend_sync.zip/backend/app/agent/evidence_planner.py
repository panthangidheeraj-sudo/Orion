"""Orchestrator-driven evidence gathering.

Historically, evidence only entered a turn when the *reasoning model itself*
emitted a ``tool_call`` block (see ``app/agent/prompts.py``'s
``TOOL_PROTOCOL`` and the round loop in ``app/agent/orchestrator.py``). That
works for ``HeuristicReasoningProvider`` because it *is* the tool-selection
logic (``app/models/heuristic.py::_choose_tools``) — it never has to "emit"
anything, it just returns the calls it wants from ``generate()``.

It does not work for a real small VLM. SmolVLM-500M-Instruct was verified
directly (not assumed) to never emit tool-call JSON, even given an explicit
tool schema in its system prompt *and* a worked few-shot example of the exact
expected format — it always answers with a bare, often-hallucinated value
instead. That is an architectural mismatch (500M-scale models are not
trained on function-calling data), not a bug to patch around in the prompt.

So the backend now decides what evidence a turn needs and fetches it itself,
*before* the reasoning model is ever called, mirroring the same job -> your
documents -> local memory -> web priority order the spec fixes (§16) and the
same two-wave shape ``_choose_tools`` already used (the second wave depends
on what the first wave found: whether local knowledge came up thin enough to
justify web search, whether a detection is worth classifying, whether the
question is spatial enough to justify opening a document page). Every
reasoning provider gets the same package handed to it in one call, through
the existing ``evidence_block()`` system message — no provider is required
to speak tool-call JSON for this basic pipeline to work.

``heuristic-offline`` keeps its own ``_choose_tools`` untouched: with this
evidence already gathered, it simply finds everything it would have asked
for already done and moves straight to composing, which is a same-behaviour
efficiency win (one reasoning call instead of up to four), not a behaviour
change. The orchestrator's model-driven tool round loop is also left in
place, unmodified, as a legacy path for any provider that genuinely can
request additional evidence beyond this plan (``vision_segment``,
``vision_track``, ``ask_user``, ``fetch_web_source`` and friends).
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, List, Sequence, Set, Tuple

from app.logging_setup import get_logger
from app.models.heuristic import _local_knowledge_thin, _retrieval_query, technical_tokens

log = get_logger(__name__)

# Mirrors heuristic._choose_tools's spatial-question cue words exactly, so
# the two "which tools does this question need" decisions stay in sync.
DIAGRAM_WORDS = ("where", "which terminal", "diagram", "schematic", "wiring",
                  "pinout", "layout", "connector", "location", "test point")

RunTools = Callable[[Sequence[Dict[str, Any]], Dict[str, Any], Sequence[str], str],
                    Awaitable[List[Tuple[str, Dict[str, Any]]]]]


def _wave_one(question: str, tool_context: Dict[str, Any], tool_names: Set[str],
              has_images: bool, done: Set[str]) -> List[Dict[str, Any]]:
    """Job memory, document chunks, vision detections, OCR — what almost every
    turn needs, none of it depending on what any other tool returns."""
    calls: List[Dict[str, Any]] = []
    tokens = technical_tokens(question)

    if has_images and "vision_detect" in tool_names and "vision_detect" not in done:
        calls.append({"tool": "vision_detect", "arguments": {}})
    if has_images and "ocr_extract" in tool_names and "ocr_extract" not in done:
        calls.append({"tool": "ocr_extract", "arguments": {}})
    if tool_context.get("document_count") and "search_documents" in tool_names \
            and "search_documents" not in done:
        calls.append({"tool": "search_documents",
                      "arguments": {"query": _retrieval_query(question, tokens)}})
    if "search_memory" in tool_names and "search_memory" not in done:
        args: Dict[str, Any] = {"query": question[:200]}
        if tool_context.get("job_id"):
            args["job_id"] = tool_context["job_id"]
        calls.append({"tool": "search_memory", "arguments": args})
    if tool_context.get("job_id") and "get_job_history" in tool_names \
            and "get_job_history" not in done:
        calls.append({"tool": "get_job_history", "arguments": {"job_id": tool_context["job_id"]}})
    return calls


def _wave_two(question: str, tool_context: Dict[str, Any], tool_names: Set[str],
              evidence: Dict[str, Any], done: Set[str]) -> List[Dict[str, Any]]:
    """Web research, classification and document-page images — only worth
    fetching once wave one shows whether they're actually needed."""
    calls: List[Dict[str, Any]] = []
    tokens = technical_tokens(question)

    # §16: web research is the last resort, only reached once local knowledge
    # (documents, memory, job history) has already come up short.
    if tool_context.get("web_search_requested") and "web_search" in tool_names \
            and "web_search" not in done and _local_knowledge_thin(evidence):
        calls.append({"tool": "web_search",
                      "arguments": {"query": _retrieval_query(question, tokens)}})

    detections = (evidence.get("vision_detect") or {}).get("detections") or []
    if detections and "vision_classify" in tool_names and "vision_classify" not in done:
        calls.append({"tool": "vision_classify",
                      "arguments": {"bbox": detections[0].get("bbox")}})

    wants_page = any(w in question.lower() for w in DIAGRAM_WORDS)
    hits = (evidence.get("search_documents") or {}).get("results") or []
    if wants_page and hits and "get_document_page" in tool_names \
            and "get_document_page" not in done:
        top = hits[0]
        calls.append({"tool": "get_document_page",
                      "arguments": {"document_id": top.get("document_id"),
                                    "page_number": top.get("page_start") or 1}})
    return calls


async def gather(
    question: str,
    tool_context: Dict[str, Any],
    tool_schemas: Sequence[Dict[str, Any]],
    allow: Sequence[str],
    conversation_id: str,
    has_images: bool,
    run_tools: RunTools,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[str]]:
    """Inspect the request, decide what evidence it needs, fetch all of it.

    Returns ``(evidence, trail, degraded)`` in exactly the shape the
    orchestrator already accumulates them in, so this slots in ahead of its
    existing model-driven round loop without changing that loop at all.
    ``run_tools`` is ``Orchestrator._run_tools`` — reused as-is for its
    concurrent execution, logging and error-wrapping rather than duplicating
    any of that here.
    """
    evidence: Dict[str, Any] = {}
    trail: List[Dict[str, Any]] = []
    degraded: List[str] = []
    tool_names = {t.get("name") for t in (tool_schemas or [])}
    done: Set[str] = set()

    async def run_wave(calls: List[Dict[str, Any]]) -> None:
        if not calls:
            return
        outcomes = await run_tools(calls, tool_context, allow, conversation_id)
        for name, payload in outcomes:
            trail.append(payload["trail"])
            evidence[name] = payload["result"]
            done.add(name)
            if payload["result"].get("degraded"):
                degraded.append(name)

    await run_wave(_wave_one(question, tool_context, tool_names, has_images, done))
    await run_wave(_wave_two(question, tool_context, tool_names, evidence, done))

    log.debug("evidence_planner: gathered %s for %r", sorted(evidence), question[:60])
    return evidence, trail, degraded
