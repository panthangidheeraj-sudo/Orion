"""GenieX reasoning adapter — Qualcomm's current Snapdragon runtime (§3, §4).

Context (Snapdragon integration phase, 2026-09-24): Qualcomm AI Hub's own
current documentation standardises on **GenieX** (superseding the older
"Genie" runtime, which the Qwen3-4B model README itself now calls
"deprecated soon") as the way a Qwen3-VL-class model actually runs on a
Snapdragon device. GenieX is architecturally different from both this
project's existing ``onnxruntime-genai`` adapter (`qwen_vl.py`, Microsoft's
runtime) and its hand-rolled ``onnxruntime`` CPU path (`smolvlm.py`) — it is
its own C SDK with real Python bindings (the ``geniex`` PyPI package, ctypes
FFI over a compiled shared library), ground-truth-inspected for this adapter
by downloading and reading the real package source rather than trusting
scraped documentation (see MODEL_STATUS.md for how).

GenieX has two backend plugins, chosen automatically from what the loaded
bundle actually is:

- ``qairt`` — Qualcomm's own NPU-only runtime. Consumes a bundle of
  Qualcomm ``.bin`` shards + a ``metadata.json`` manifest. This is the
  genuine Hexagon-NPU path.
- ``llama_cpp`` — a GGUF-consuming llama.cpp build. Its ``device_map="npu"``
  alias *also* targets a Hexagon HTP ggml backend (``HTP0``), so this is not
  a "CPU-only" fallback in the way the project's other CPU adapters are —
  but it is a different code path from ``qairt`` and gets no NPU claim
  without the same runtime confirmation applied below.

**Two hard platform facts, verified directly in this sandbox, not assumed:**

1.  ``pip install geniex`` only succeeds on Linux aarch64 or Windows arm64
    (its own README states this, and this sandbox's real install attempt
    failed with ``RuntimeError: Unsupported platform ('linux', 'x86_64')
    for prebuilt geniex SDK`` — see MODEL_STATUS.md). It cannot be
    installed or exercised in this x86_64 cloud sandbox at all, ever. This
    adapter can only ever report ``unavailable`` here, honestly, for that
    reason alone — independent of whether a bundle exists.
2.  Compiling/exporting a model *for* Snapdragon via Qualcomm AI Hub (the
    ``qai-hub``/``qai-hub-models`` tooling) can run from any machine with a
    real AI Hub account and network access to ``aihub.qualcomm.com`` — that
    part is a cloud job submission, not local execution. But *loading and
    running* the resulting GenieX bundle to actually serve inference (this
    adapter, at runtime) requires the process itself to be running on
    Snapdragon-class ARM64 hardware. An AI Hub export alone does not make
    this adapter ready anywhere except on that target hardware.

Two rules this file exists to honour (§4, base.py's module docstring),
exactly as in every other adapter in this package:

1.  If the ``geniex`` package is not importable, or no bundle is present
    under ``data/models/<model_id>/geniex/``, this reports ``unavailable``
    and the registry falls through to the next candidate. It never
    half-loads.
2.  ``accelerator``/``npu`` are read from ``GenerateOutput.profile`` after a
    real warm-up ``generate()`` call actually completed on the loaded
    bundle -- never from what ``device_map`` requested. This mirrors
    ``runtime.py``'s rule for ``session.get_providers()`` being the ground
    truth for the ONNX path: geniex's own post-hoc profile fields are the
    equivalent ground truth here, because they reflect what
    ``resolve_device_map`` + the native runtime actually settled on, not
    the alias that was asked for.

**This does not mean "NPU support" is claimed anywhere in this build.**
Nothing here has run on Snapdragon hardware; this adapter has never reported
``ready`` in this sandbox and cannot, by fact (1) above. §4's instruction --
"do not claim NPU support until an actual Qualcomm AI Hub profile/export
succeeds" -- is honoured by construction: this file only ever sets
``npu=True`` from a real, on-this-host generate() call's own profile data,
which by definition cannot happen until someone runs this on real Snapdragon
hardware with a real bundle. See MODEL_STATUS.md §4 for the full trail and
scripts/export_reasoning_geniex.py + scripts/setup_qai_hub_auth.md for how to
actually produce and load a bundle on that hardware.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Dict, List, Optional, Sequence

from app.config import settings
from app.errors import ModelUnavailable
from app.logging_setup import get_logger
from app.models.base import READY, ImageRef, ModelHealth, ReasoningProvider
from app.models.qwen_vl import parse_tool_calls
from app.models.runtime import model_dir
from app.util import ms

log = get_logger(__name__)

FALLBACK = "onnxruntime-genai / onnx-cpu-smolvlm / heuristic-offline reasoner"

GENIEX_BUNDLE_SUBDIR = "geniex"


class GenieXReasoningProvider(ReasoningProvider):
    """GenieX-backed VLM adapter. Bring-your-own bundle, never fetches at runtime.

    ``data/models/<model_id>/geniex/`` must already contain either:

    - a ``qairt`` bundle: ``metadata.json`` + one or more ``*.bin`` shards, or
    - a ``llama_cpp`` bundle: a ``*.gguf`` file (+ optional ``mmproj*.gguf``).

    Nothing is downloaded here — see ``scripts/export_reasoning_geniex.py``,
    which must be run on a machine with real Qualcomm AI Hub access to
    produce one.
    """

    def __init__(self, model_id: Optional[str] = None, max_new_tokens: int = 384) -> None:
        super().__init__(model_id or settings.reasoning_model_id, "geniex-npu")
        self.max_new_tokens = max_new_tokens
        self._model = None
        self._geniex = None

    # ------------------------------------------------------------------ load
    def _load(self) -> None:
        try:
            import geniex  # type: ignore
            from geniex import AutoModelForVision2Seq  # type: ignore
        except Exception as exc:
            raise ModelUnavailable(
                f"geniex not importable ({type(exc).__name__}: {exc}). It only "
                "installs on Linux aarch64 or Windows arm64 (Snapdragon-class "
                "hosts) -- see scripts/setup_qai_hub_auth.md. Not installable "
                "or usable in a generic x86_64 dev sandbox at all.",
                model=self.model_id, fallback=FALLBACK,
            )

        bundle = model_dir(self.model_id) / GENIEX_BUNDLE_SUBDIR
        has_qairt = (bundle / "metadata.json").exists() and any(bundle.glob("*.bin"))
        has_llama_cpp = any(bundle.glob("*.gguf"))
        if not bundle.exists() or not (has_qairt or has_llama_cpp):
            raise ModelUnavailable(
                f"no GenieX bundle under data/models/{self.model_id}/{GENIEX_BUNDLE_SUBDIR}/ "
                "(expected metadata.json + *.bin shards for the qairt/NPU plugin, "
                "or a *.gguf for the llama_cpp plugin). Run "
                "scripts/export_reasoning_geniex.py on a machine with Qualcomm AI "
                "Hub access to produce one -- see MODEL_STATUS.md.",
                model=self.model_id, fallback=FALLBACK,
            )

        device_map = settings.geniex_device_map
        t0 = ms()
        try:
            model = AutoModelForVision2Seq.from_pretrained(str(bundle), device_map=device_map)
        except Exception as exc:
            raise ModelUnavailable(
                f"geniex failed to load the bundle at {bundle} "
                f"({type(exc).__name__}: {exc})",
                model=self.model_id, fallback=FALLBACK,
            )

        # Real smoke-test call, not a construction-only check -- see module
        # docstring rule 2. backend/device below are read from
        # GenerateOutput.profile after this call actually ran, never guessed.
        try:
            warm_prompt = model.tokenizer.apply_chat_template(
                [{"role": "user", "content": "Hi"}],
                tokenize=False, add_generation_prompt=True,
            )
            warm = model.generate(warm_prompt, max_new_tokens=4)
        except Exception as exc:
            try:
                model.close()
            except Exception:
                pass
            raise ModelUnavailable(
                f"geniex bundle loaded but the warm-up generate() call failed "
                f"({type(exc).__name__}: {exc}) -- not marking this provider ready",
                model=self.model_id, fallback=FALLBACK,
            )

        profile = warm.profile
        backend = (profile.backend or "").strip()
        device = (profile.device or "").strip()
        npu = backend == "qairt" or device.upper().startswith("HTP")
        accelerator = "npu" if npu else ("gpu" if device in ("GPUOpenCL",) else "cpu")

        self._geniex = geniex
        self._model = model
        self._health = ModelHealth(
            role=self.role, provider=self.provider, model_id=self.model_id, status=READY,
            runtime="geniex", accelerator=accelerator, npu=npu,
            asset_path=str(bundle), load_ms=round(ms() - t0, 2),
            detail={
                "backend_plugin": backend or "unknown",
                "device_id": device or "unknown",
                "quant": profile.quant,
                "requested_device_map": device_map,
                "geniex_version": getattr(geniex, "__version__", None),
                "max_new_tokens": self.max_new_tokens,
                "npu_note": (
                    "npu=true here means the GenieX runtime itself reported the "
                    "qairt (Hexagon NPU) plugin, or an HTP device id, after a "
                    "real generate() call completed on this host. It is not a "
                    "substitute for an actual Qualcomm AI Hub profile of this "
                    "export -- see MODEL_STATUS.md §4."
                ),
            },
        )

    def capabilities(self) -> Dict[str, Any]:
        return {**super().capabilities(), "streaming": True, "images": True,
                "tool_calls": "prompted+native_template",
                "accelerator": self._health.accelerator}

    # --------------------------------------------------------------- prompt
    def _prepare(self, messages: Sequence[Dict[str, Any]], images: Optional[Sequence[ImageRef]],
                 tools: Optional[Sequence[Dict[str, Any]]]) -> tuple:
        imgs = list(images or [])[:4]
        image_paths = [im.path for im in imgs]
        gmsgs: List[Dict[str, Any]] = []
        last_idx = len(messages) - 1
        for idx, m in enumerate(messages):
            role = str(m.get("role", "user"))
            text = str(m.get("content", ""))
            if idx == last_idx and image_paths:
                content: List[Dict[str, str]] = [{"type": "image", "image": p} for p in image_paths]
                content.append({"type": "text", "text": text})
                gmsgs.append({"role": role, "content": content})
            else:
                gmsgs.append({"role": role, "content": text})
        tools_json = json.dumps(list(tools)) if tools else None
        assert self._model is not None
        prompt = self._model.tokenizer.apply_chat_template(
            gmsgs, tokenize=False, add_generation_prompt=True, tools=tools_json,
        )
        return prompt, image_paths

    def _usage_from_profile(self, profile) -> Dict[str, Any]:
        if profile is None:
            return {}
        return {
            "prompt_tokens": profile.prompt_tokens,
            "output_tokens": profile.generated_tokens,
            "decode_tokens_per_sec": round(profile.decode_speed, 2),
            "prefill_tokens_per_sec": round(profile.prefill_speed, 2),
            "ttft_ms": round(profile.ttft / 1000, 2) if profile.ttft else 0,
            "stop_reason": profile.stop_reason,
            "backend": profile.backend,
            "device": profile.device,
        }

    # ---------------------------------------------------------------- API
    async def generate(self, messages, images=None, tools=None, context=None) -> Dict[str, Any]:
        self.require_ready(fallback=FALLBACK)
        loop = asyncio.get_running_loop()
        prompt, image_paths = self._prepare(messages, images, tools)

        def _work():
            assert self._model is not None
            return self._model.generate(prompt, images=image_paths, max_new_tokens=self.max_new_tokens)

        output = await loop.run_in_executor(None, _work)
        clean, calls = parse_tool_calls(output.text)
        return {"text": clean, "tool_calls": calls, "model": self.model_id,
                "usage": self._usage_from_profile(output.profile)}

    def supports_streaming(self) -> bool:
        return True

    async def stream(self, messages, images=None, tools=None, context=None) -> AsyncIterator[Dict[str, Any]]:
        self.require_ready(fallback=FALLBACK)
        loop = asyncio.get_running_loop()
        prompt, image_paths = self._prepare(messages, images, tools)

        queue: "asyncio.Queue[tuple]" = asyncio.Queue()

        def _produce() -> None:
            try:
                assert self._model is not None
                streamer = self._model.generate(
                    prompt, images=image_paths, max_new_tokens=self.max_new_tokens, stream=True,
                )
                for chunk in streamer:
                    loop.call_soon_threadsafe(queue.put_nowait, ("chunk", chunk))
                loop.call_soon_threadsafe(queue.put_nowait, ("done", streamer.output))
            except Exception as exc:  # pragma: no cover - defensive
                loop.call_soon_threadsafe(queue.put_nowait, ("error", exc))

        fut = loop.run_in_executor(None, _produce)
        full_parts: List[str] = []
        while True:
            kind, payload = await queue.get()
            if kind == "chunk":
                full_parts.append(payload)
                yield {"type": "text", "value": payload}
            elif kind == "error":
                await fut
                raise payload
            else:
                output = payload
                text = output.text if output else "".join(full_parts)
                clean, calls = parse_tool_calls(text)
                usage = self._usage_from_profile(output.profile if output else None)
                yield {"type": "done", "value": {"text": clean, "tool_calls": calls,
                                                  "model": self.model_id, "usage": usage}}
                break
        await fut
